# NO3SYS Architecture Overview

## Geometric Intelligence Stack

NO3SYS implements intelligence as sacred geometry — each shape represents a computational role while reinforcing others through shared state and event flow.

```
        ╭─────────────╮
       ╱   HEXAGON     ╲      Modular State Interconnection
      ╱   (6 Services)   ╲
     ╱─────────────────────╲
    ╱       PENTAGON        ╲   Expansion and Emergence
   ╱      (5 Services)       ╲
  ╱─────────────────────────────╲
 ╱          TRIANGLE             ╲  Triadic Intelligence Engine
╱         (3 Agents + Router)      ╲
╲──────────────────────────────────╱
 ╲            CIRCLE               ╱  Feedback and Learning Cycles
  ╲       (2 Pipeline Services)    ╱
   ╲──────────────────────────────╱
    ╲          SQUARE             ╱   Structural Memory
     ╲    (4 Core Services)       ╱
      ╲──────────────────────────╱
```

## Layer Interactions

### Data Flow

1. **User Request** → API Gateway → Identity Service (authentication)
2. **Session Creation** → Session Service (FSM state: START → ENGAGE)
3. **Message Processing** → Conversation Service (persistence + embeddings)
4. **Knowledge Extraction** → Knowledge Graph Service (Neo4j entities/relations)
5. **Intelligence Orchestration** → Modes Router → Retriever + Reasoner + Generator
6. **Memory Formation** → Memory Feedback Service (summarization + caching)
7. **Learning Loop** → Retraining Pipeline (feedback aggregation + model improvement)

### Event Streaming

All state changes flow through Kafka topics:
- `session-events` - Session FSM transitions
- `message-created` - New conversation messages
- `entity-extracted` - Knowledge graph updates
- `feedback-submitted` - User feedback for learning
- `training-triggered` - Model retraining events
- `model-ready-for-deployment` - CD pipeline triggers

## Service Mesh

### Internal Communication
- **gRPC**: Inter-agent communication (low latency)
- **REST**: Service-to-service APIs
- **GraphQL**: Federated queries (Hexagon Layer)
- **WebSockets**: Real-time proactive suggestions

### External Communication
- **API Gateway**: Kong/Nginx Ingress (rate limiting, auth)
- **Load Balancing**: NGINX Ingress Controller
- **Service Discovery**: Kubernetes DNS

## Persistence Strategy

| Data Type | Store | Use Case |
|-----------|-------|----------|
| Structured Data | PostgreSQL | Users, sessions, messages |
| Vector Embeddings | pgvector | Semantic search |
| Graph Data | Neo4j | Entities, relationships, reasoning |
| Cache | Redis | Session state, fast recall (<100ms) |
| Events | Kafka | Event streaming, audit logs |
| Files | S3 | Attachments, exports |

## Scalability

### Horizontal Pod Autoscaling
- CPU threshold: 70%
- Memory threshold: 80%
- Min/Max replicas per service

### Database Scaling
- PostgreSQL: Read replicas for query workloads
- Neo4j: Causal clustering for graph operations
- Redis: Cluster mode for cache sharding

## Security

- JWT-based authentication
- API key support for service accounts
- mTLS between services (Istio optional)
- Secrets management via Kubernetes Secrets
- Network policies for service isolation
