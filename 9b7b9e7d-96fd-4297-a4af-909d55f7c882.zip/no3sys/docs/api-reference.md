# NO3SYS API Reference

## Base URL

```
Local: http://localhost:8080/api/v1
Production: https://api.no3sys.io/api/v1
```

## Authentication

All endpoints (except `/auth/*`) require a Bearer token:

```bash
Authorization: Bearer <access_token>
```

## Identity Service

### Register
```http
POST /auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "username": "username",
  "password": "securepassword",
  "displayName": "User Name"
}
```

**Response:**
```json
{
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "username": "username",
    "displayName": "User Name",
    "createdAt": "2024-01-01T00:00:00Z"
  },
  "tokens": {
    "accessToken": "jwt_token",
    "refreshToken": "refresh_token",
    "expiresIn": 900
  }
}
```

### Login
```http
POST /auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "securepassword"
}
```

### Get Current User
```http
GET /auth/me
Authorization: Bearer <token>
```

## Session Service

### Create Session
```http
POST /sessions
Authorization: Bearer <token>
Content-Type: application/json

{
  "userId": "uuid",
  "title": "Session Title",
  "context": {},
  "metadata": {}
}
```

### Transition State
```http
POST /sessions/:sessionId/transition
Authorization: Bearer <token>
Content-Type: application/json

{
  "event": "ACTIVATE",
  "metadata": {}
}
```

**States:** `START` → `ENGAGE` → `RESOLVE` → `ARCHIVE`

**Events:** `INITIATE`, `ACTIVATE`, `CONCLUDE`, `FINALIZE`, `REACTIVATE`

## Conversation Service

### Create Conversation
```http
POST /conversations
Authorization: Bearer <token>
Content-Type: application/json

{
  "userId": "uuid",
  "sessionId": "uuid",
  "title": "Conversation Title"
}
```

### Send Message
```http
POST /messages
Authorization: Bearer <token>
Content-Type: application/json

{
  "conversationId": "uuid",
  "role": "user",
  "content": "Message content",
  "metadata": {}
}
```

### Semantic Search
```http
POST /messages/search
Authorization: Bearer <token>
Content-Type: application/json

{
  "conversationId": "uuid",
  "query": "search query",
  "limit": 10
}
```

## Knowledge Graph Service

### Create Entity
```http
POST /entities
Authorization: Bearer <token>
Content-Type: application/json

{
  "type": "Person",
  "name": "Entity Name",
  "properties": {},
  "source": "conversation",
  "confidence": 0.95
}
```

### Create Relationship
```http
POST /relationships
Authorization: Bearer <token>
Content-Type: application/json

{
  "fromId": "entity-uuid",
  "toId": "entity-uuid",
  "type": "KNOWS",
  "properties": {},
  "confidence": 0.9
}
```

### Path Finding
```http
POST /queries/path
Authorization: Bearer <token>
Content-Type: application/json

{
  "fromId": "entity-uuid",
  "toId": "entity-uuid",
  "maxDepth": 4
}
```

### Centrality Analysis
```http
POST /queries/centrality
Authorization: Bearer <token>
Content-Type: application/json

{
  "type": "degree",
  "limit": 20
}
```

## Intelligence Orchestration

### Full Orchestration
```http
POST /orchestrate/orchestrate
Authorization: Bearer <token>
Content-Type: application/json

{
  "query": "User question",
  "conversationId": "uuid",
  "mode": "balanced",
  "context": "optional context"
}
```

**Modes:** `analytic`, `creative`, `empathetic`, `balanced`

**Response:**
```json
{
  "response": "Generated response",
  "mode": "balanced",
  "trace": {
    "steps": [
      { "agent": "retriever", "duration": 150 },
      { "agent": "reasoner", "duration": 800 },
      { "agent": "generator", "duration": 1200 }
    ],
    "totalDuration": 2150
  },
  "sources": {
    "vector": 5,
    "graph": 3
  }
}
```

### Quick Response
```http
POST /orchestrate/quick
Authorization: Bearer <token>
Content-Type: application/json

{
  "query": "User question",
  "conversationId": "uuid",
  "mode": "balanced"
}
```

## Memory & Feedback

### Create Memory Summary
```http
POST /memory/summarize
Authorization: Bearer <token>
Content-Type: application/json

{
  "conversationId": "uuid",
  "content": "Content to summarize"
}
```

### Semantic Memory Search
```http
POST /memory/search
Authorization: Bearer <token>
Content-Type: application/json

{
  "query": "search query",
  "userId": "uuid",
  "limit": 10
}
```

### Submit Feedback
```http
POST /feedback
Authorization: Bearer <token>
Content-Type: application/json

{
  "messageId": "uuid",
  "rating": 5,
  "comment": "Great response!",
  "tags": ["accurate", "helpful"]
}
```

## Error Responses

All errors follow this format:

```json
{
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable message",
    "requestId": "uuid"
  }
}
```

**Common Codes:**
- `UNAUTHORIZED` - Missing or invalid token
- `TOKEN_EXPIRED` - Token has expired
- `VALIDATION_ERROR` - Request validation failed
- `NOT_FOUND` - Resource not found
- `INTERNAL_ERROR` - Server error

## Rate Limiting

- 100 requests per 15 minutes per IP
- 1000 requests per hour per user

Rate limit headers:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 99
X-RateLimit-Reset: 1640995200
```
