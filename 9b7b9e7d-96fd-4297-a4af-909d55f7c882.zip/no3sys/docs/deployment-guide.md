# NO3SYS Deployment Guide

## Prerequisites

- Docker 24.0+
- Docker Compose 2.20+
- Kubernetes 1.28+ (for production)
- kubectl configured
- Helm 3.12+ (optional)

## Local Development

### 1. Clone and Setup

```bash
cd no3sys
```

### 2. Environment Configuration

Create `.env` file in the project root:

```bash
# Required
OPENAI_API_KEY=sk-your-key-here

# Optional (defaults provided)
POSTGRES_USER=no3sys
POSTGRES_PASSWORD=no3sys_secret
NEO4J_PASSWORD=no3sys_secret
JWT_SECRET=no3sys_jwt_secret_key
```

### 3. Start Infrastructure

```bash
docker-compose -f infrastructure/docker/docker-compose.yml up -d postgres neo4j redis kafka
```

Wait for services to be healthy:
```bash
docker-compose -f infrastructure/docker/docker-compose.yml ps
```

### 4. Start All Services

```bash
docker-compose -f infrastructure/docker/docker-compose.yml up -d
```

### 5. Verify Installation

```bash
# Check API Gateway
curl http://localhost:8080/health

# Check individual services
curl http://localhost:3001/health  # Identity
curl http://localhost:3002/health  # Session
curl http://localhost:3023/health  # Modes Router
```

## Production Deployment

### 1. Create Namespace

```bash
kubectl apply -f infrastructure/kubernetes/namespace.yml
```

### 2. Configure Secrets

Edit `infrastructure/kubernetes/secrets-template.yml` with production values:

```bash
# Generate secure secrets
export POSTGRES_PASSWORD=$(openssl rand -base64 32)
export NEO4J_PASSWORD=$(openssl rand -base64 32)
export JWT_SECRET=$(openssl rand -base64 64)

# Create secret
kubectl create secret generic no3sys-secrets \
  --from-literal=postgres-password="$POSTGRES_PASSWORD" \
  --from-literal=neo4j-auth="neo4j/$NEO4J_PASSWORD" \
  --from-literal=jwt-secret="$JWT_SECRET" \
  --from-literal=openai-api-key="$OPENAI_API_KEY" \
  -n no3sys
```

### 3. Deploy Infrastructure

```bash
kubectl apply -f infrastructure/kubernetes/configmap.yml
kubectl apply -f infrastructure/kubernetes/postgres.yml
kubectl apply -f infrastructure/kubernetes/redis.yml
kubectl apply -f infrastructure/kubernetes/neo4j.yml
kubectl apply -f infrastructure/kubernetes/kafka.yml
```

### 4. Build and Push Images

```bash
# Build all service images
docker build -t no3sys/identity-service:latest services/square-layer/identity-service
docker build -t no3sys/session-service:latest services/square-layer/session-service
docker build -t no3sys/conversation-service:latest services/square-layer/conversation-service
docker build -t no3sys/knowledge-graph-service:latest services/square-layer/knowledge-graph-service
docker build -t no3sys/memory-feedback-service:latest services/circle-layer/memory-feedback-service
docker build -t no3sys/retraining-pipeline:latest services/circle-layer/retraining-pipeline
docker build -t no3sys/retriever-agent:latest services/triangle-layer/retriever-agent
docker build -t no3sys/reasoner-agent:latest services/triangle-layer/reasoner-agent
docker build -t no3sys/generator-agent:latest services/triangle-layer/generator-agent
docker build -t no3sys/modes-router:latest services/triangle-layer/modes-router
docker build -t no3sys/api-gateway:latest services/api-gateway

# Push to registry
docker push no3sys/identity-service:latest
# ... push all images
```

### 5. Deploy Services

```bash
kubectl apply -f infrastructure/kubernetes/identity-service.yml
# Apply other service manifests similarly
kubectl apply -f infrastructure/kubernetes/api-gateway.yml
```

### 6. Verify Deployment

```bash
# Check pods
kubectl get pods -n no3sys

# Check services
kubectl get svc -n no3sys

# Check logs
kubectl logs -n no3sys -l app=api-gateway --tail=100
```

## Monitoring

### Prometheus + Grafana (Optional)

```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm install prometheus prometheus-community/kube-prometheus-stack -n no3sys
```

### Jaeger Tracing (Optional)

```bash
kubectl apply -f https://raw.githubusercontent.com/jaegertracing/jaeger-operator/main/deploy/crds/jaegertracing.io_jaegers_crd.yaml
```

## Troubleshooting

### Service Won't Start

```bash
# Check logs
kubectl logs -n no3sys deployment/identity-service

# Check events
kubectl get events -n no3sys --sort-by='.lastTimestamp'

# Check resource usage
kubectl top pods -n no3sys
```

### Database Connection Issues

```bash
# Test PostgreSQL
kubectl exec -it -n no3sys deployment/postgres -- psql -U no3sys -d no3sys_core -c "SELECT 1"

# Test Neo4j
kubectl exec -it -n no3sys deployment/neo4j -- cypher-shell -u neo4j -p "$NEO4J_PASSWORD" "RETURN 1"
```

### Reset Everything

```bash
# Local
docker-compose -f infrastructure/docker/docker-compose.yml down -v

# Kubernetes
kubectl delete namespace no3sys
kubectl apply -f infrastructure/kubernetes/namespace.yml
```

## CI/CD Pipeline

Example GitHub Actions workflow:

```yaml
name: Deploy NO3SYS

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Build images
        run: |
          docker build -t no3sys/identity-service:${{ github.sha }} services/square-layer/identity-service
          # ... build all images
      
      - name: Push to registry
        run: |
          echo ${{ secrets.DOCKER_PASSWORD }} | docker login -u ${{ secrets.DOCKER_USERNAME }} --password-stdin
          docker push no3sys/identity-service:${{ github.sha }}
      
      - name: Deploy to Kubernetes
        run: |
          kubectl set image deployment/identity-service identity-service=no3sys/identity-service:${{ github.sha }} -n no3sys
          # ... update all deployments
```
