# NO3SYS — Recursive Geometric Intelligence Architecture

**NO3SYS** (pronounced *Noesis*) is a sacred-geometry-inspired cognitive system where geometric forms map to computational roles. Each layer represents a functional domain in a recursive intelligence stack.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    HEXAGON LAYER                            │
│         Modular State Interconnection (6 Services)          │
├─────────────────────────────────────────────────────────────┤
│                    PENTAGON LAYER                           │
│         Expansion and Emergence (Insights, Patterns)        │
├─────────────────────────────────────────────────────────────┤
│                    TRIANGLE LAYER                           │
│         Triadic Intelligence Engine (3 Agents)              │
├─────────────────────────────────────────────────────────────┤
│                    CIRCLE LAYER                             │
│         Feedback and Learning Cycles (State Machine)        │
├─────────────────────────────────────────────────────────────┤
│                    SQUARE LAYER                             │
│         Structural Memory (Relational + Graph)              │
└─────────────────────────────────────────────────────────────┘
```

## Quick Start

### Local Development

```bash
# Start all services with Docker Compose
docker-compose -f infrastructure/docker/docker-compose.yml up -d

# Or start individual layers
docker-compose -f infrastructure/docker/docker-compose.yml up square-layer -d
```

### Production Deployment

```bash
# Apply Kubernetes manifests
kubectl apply -f infrastructure/kubernetes/namespace.yml
kubectl apply -f infrastructure/kubernetes/
```

## Layer Documentation

- [Square Layer](./docs/square-layer.md) - Structural Memory
- [Circle Layer](./docs/circle-layer.md) - Feedback and Learning
- [Triangle Layer](./docs/triangle-layer.md) - Triadic Intelligence
- [Pentagon Layer](./docs/pentagon-layer.md) - Expansion and Emergence
- [Hexagon Layer](./docs/hexagon-layer.md) - Modular Interconnection

## System Properties

- ✅ Event-driven via message streaming (Kafka)
- ✅ Hybrid persistence (PostgreSQL + Neo4j + Redis)
- ✅ Explainable reasoning storage
- ✅ Horizontal scalability (Kubernetes)
- ✅ Closed-loop learning pipelines
- ✅ Low-latency recall (<100ms)
- ✅ Modular agent orchestration
- ✅ Mode-aware cognition
- ✅ Real-time proactive insight delivery

## Service Mesh

- **API Gateway**: Kong/Nginx Ingress
- **Service Discovery**: Kubernetes DNS
- **Load Balancing**: NGINX Ingress Controller
- **Observability**: Prometheus + Grafana + Jaeger

## License

MIT License - See LICENSE file for details.
