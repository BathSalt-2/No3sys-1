import { Express, Request, Response } from 'express';
import { createProxyMiddleware } from 'http-proxy-middleware';
import { authenticate } from '../middleware/auth';

// Service URLs from environment
const SERVICES = {
  identity: process.env.IDENTITY_SERVICE_URL || 'http://localhost:3001',
  session: process.env.SESSION_SERVICE_URL || 'http://localhost:3002',
  conversation: process.env.CONVERSATION_SERVICE_URL || 'http://localhost:3003',
  knowledgeGraph: process.env.KNOWLEDGE_GRAPH_SERVICE_URL || 'http://localhost:3004',
  memoryFeedback: process.env.MEMORY_FEEDBACK_SERVICE_URL || 'http://localhost:3010',
  retraining: process.env.RETRAINING_PIPELINE_URL || 'http://localhost:3011',
  retriever: process.env.RETRIEVER_AGENT_URL || 'http://localhost:3020',
  reasoner: process.env.REASONER_AGENT_URL || 'http://localhost:3021',
  generator: process.env.GENERATOR_AGENT_URL || 'http://localhost:3022',
  modesRouter: process.env.MODES_ROUTER_URL || 'http://localhost:3023',
};

// Create proxy middleware with options
const createProxy = (target: string, pathRewrite: any = {}) => {
  return createProxyMiddleware({
    target,
    changeOrigin: true,
    pathRewrite,
    onError: (err, req, res) => {
      console.error(`Proxy error for ${target}:`, err.message);
      (res as Response).status(503).json({
        error: 'Service Unavailable',
        message: 'The requested service is temporarily unavailable',
      });
    },
    onProxyReq: (proxyReq, req, res) => {
      // Forward request ID
      const requestId = (req as any).requestId;
      if (requestId) {
        proxyReq.setHeader('x-request-id', requestId);
      }
      // Forward auth header if present
      const authHeader = req.headers.authorization;
      if (authHeader) {
        proxyReq.setHeader('authorization', authHeader);
      }
    },
  });
};

export const setupRoutes = (app: Express) => {
  // Public routes (no auth required)
  app.use('/api/v1/auth', createProxy(SERVICES.identity, { '^/api/v1/auth': '/auth' }));
  
  // Health checks for all services
  app.get('/api/v1/health/:service', async (req, res) => {
    const { service } = req.params;
    const serviceUrl = SERVICES[service as keyof typeof SERVICES];
    if (!serviceUrl) {
      return res.status(404).json({ error: 'Service not found' });
    }
    
    try {
      const response = await fetch(`${serviceUrl}/health`);
      const data = await response.json();
      res.status(response.status).json(data);
    } catch (error) {
      res.status(503).json({ error: 'Service unreachable', service });
    }
  });

  // Protected routes (auth required)
  app.use('/api/v1/users', authenticate, createProxy(SERVICES.identity, { '^/api/v1/users': '/users' }));
  app.use('/api/v1/api-keys', authenticate, createProxy(SERVICES.identity, { '^/api/v1/api-keys': '/api-keys' }));
  
  // Session routes
  app.use('/api/v1/sessions', authenticate, createProxy(SERVICES.session, { '^/api/v1/sessions': '/sessions' }));
  app.use('/api/v1/fsm', authenticate, createProxy(SERVICES.session, { '^/api/v1/fsm': '/fsm' }));
  
  // Conversation routes
  app.use('/api/v1/conversations', authenticate, createProxy(SERVICES.conversation, { '^/api/v1/conversations': '/conversations' }));
  app.use('/api/v1/messages', authenticate, createProxy(SERVICES.conversation, { '^/api/v1/messages': '/messages' }));
  
  // Knowledge Graph routes
  app.use('/api/v1/entities', authenticate, createProxy(SERVICES.knowledgeGraph, { '^/api/v1/entities': '/entities' }));
  app.use('/api/v1/relationships', authenticate, createProxy(SERVICES.knowledgeGraph, { '^/api/v1/relationships': '/relationships' }));
  app.use('/api/v1/queries', authenticate, createProxy(SERVICES.knowledgeGraph, { '^/api/v1/queries': '/queries' }));
  
  // Memory & Feedback routes
  app.use('/api/v1/memory', authenticate, createProxy(SERVICES.memoryFeedback, { '^/api/v1/memory': '/memory' }));
  app.use('/api/v1/feedback', authenticate, createProxy(SERVICES.memoryFeedback, { '^/api/v1/feedback': '/feedback' }));
  
  // Training routes
  app.use('/api/v1/training', authenticate, createProxy(SERVICES.retraining, { '^/api/v1/training': '/pipeline' }));
  app.use('/api/v1/metrics', authenticate, createProxy(SERVICES.retraining, { '^/api/v1/metrics': '/metrics' }));
  
  // Agent routes
  app.use('/api/v1/retrieve', authenticate, createProxy(SERVICES.retriever, { '^/api/v1/retrieve': '/retrieve' }));
  app.use('/api/v1/reason', authenticate, createProxy(SERVICES.reasoner, { '^/api/v1/reason': '/reason' }));
  app.use('/api/v1/generate', authenticate, createProxy(SERVICES.generator, { '^/api/v1/generate': '/generate' }));
  
  // Orchestration routes
  app.use('/api/v1/orchestrate', authenticate, createProxy(SERVICES.modesRouter, { '^/api/v1/orchestrate': '/route' }));
  app.use('/api/v1/modes', authenticate, createProxy(SERVICES.modesRouter, { '^/api/v1/modes': '/route/modes' }));
  
  // GraphQL endpoint (if implemented)
  app.use('/api/v1/graphql', authenticate, createProxy(SERVICES.conversation, { '^/api/v1/graphql': '/graphql' }));
};
