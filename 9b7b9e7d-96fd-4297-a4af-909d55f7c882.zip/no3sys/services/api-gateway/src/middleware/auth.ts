import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { AppError } from './error-handler';
import { logger } from '../utils/logger';

const JWT_SECRET = process.env.JWT_SECRET || 'no3sys_jwt_secret_key';

declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        email: string;
      };
    }
  }
}

export const authenticate = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new AppError(401, 'Authentication required', 'UNAUTHORIZED');
    }

    const token = authHeader.substring(7);
    
    const payload = jwt.verify(token, JWT_SECRET) as any;
    
    if (payload.type !== 'access') {
      throw new AppError(401, 'Invalid token type', 'INVALID_TOKEN_TYPE');
    }

    req.user = { id: payload.userId, email: payload.email };
    next();
  } catch (error) {
    if (error instanceof AppError) {
      return next(error);
    }
    if (error instanceof jwt.TokenExpiredError) {
      return next(new AppError(401, 'Token has expired', 'TOKEN_EXPIRED'));
    }
    if (error instanceof jwt.JsonWebTokenError) {
      return next(new AppError(401, 'Invalid token', 'INVALID_TOKEN'));
    }
    next(error);
  }
};

export const optionalAuth = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return next();
    }

    const token = authHeader.substring(7);
    const payload = jwt.verify(token, JWT_SECRET) as any;
    
    if (payload.type === 'access') {
      req.user = { id: payload.userId, email: payload.email };
    }
    
    next();
  } catch (error) {
    // Silently ignore auth errors for optional auth
    next();
  }
};
