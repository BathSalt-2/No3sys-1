import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { PrismaClient } from '@prisma/client';
import Redis from 'ioredis';
import neo4j from 'neo4j-driver';
import OpenAI from 'openai';
import { logger } from './utils/logger';
import { retrieveRoutes } from './routes/retrieve';
import { errorHandler } from './middleware/error-handler';
import { requestId } from './middleware/request-id';

const app = express();
const port = process.env.PORT || 3020;

export const prisma = new PrismaClient();
export const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');
export const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export const neo4jDriver = neo4j.driver(
  process.env.NEO4J_URI || 'bolt://localhost:7687',
  neo4j.auth.basic(
    process.env.NEO4J_USER || 'neo4j',
    process.env.NEO4J_PASSWORD || 'password'
  )
);

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan('combined', { stream: { write: (msg) => logger.info(msg.trim()) } }));
app.use(requestId);

app.get('/health', async (req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    await redis.ping();
    const session = neo4jDriver.session();
    await session.run('RETURN 1');
    await session.close();
    res.json({ status: 'healthy', service: 'retriever-agent' });
  } catch (error) {
    res.status(503).json({ status: 'unhealthy' });
  }
});

app.use('/retrieve', retrieveRoutes);

app.use(errorHandler);

const gracefulShutdown = async () => {
  await prisma.$disconnect();
  await redis.quit();
  await neo4jDriver.close();
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

app.listen(port, () => {
  logger.info(`Retriever Agent running on port ${port}`);
});
