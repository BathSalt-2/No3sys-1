import { Router } from 'express';
import { prisma, redis, openai, neo4jDriver } from '../index';
import { AppError } from '../middleware/error-handler';
import { logger } from '../utils/logger';

const router = Router();

// Generate embedding
const generateEmbedding = async (content: string): Promise<number[]> => {
  const response = await openai.embeddings.create({
    model: 'text-embedding-3-small',
    input: content,
  });
  return response.data[0].embedding;
};

// Hybrid search: vector + graph
router.post('/hybrid', async (req, res, next) => {
  try {
    const { query, userId, conversationId, limit = '10' } = req.body;

    const queryEmbedding = await generateEmbedding(query);

    // Vector search from PostgreSQL
    const vectorResults = await prisma.$queryRaw`
      SELECT id, content, metadata, created_at,
             embedding <=> ${queryEmbedding}::vector as distance
      FROM messages
      WHERE conversation_id = ${conversationId}
      ORDER BY embedding <=> ${queryEmbedding}::vector
      LIMIT ${parseInt(limit)}
    `;

    // Graph search from Neo4j
    const session = neo4jDriver.session();
    const graphResult = await session.run(
      `
      CALL db.index.fulltext.queryNodes('entitySearch', $query) YIELD node, score
      MATCH (node)-[r]-(related:Entity)
      RETURN node, collect({relationship: r, entity: related}) as related
      LIMIT $limit
      `,
      { query, limit: parseInt(limit) }
    );
    await session.close();

    const graphResults = graphResult.records.map((record) => ({
      entity: record.get('node').properties,
      related: record.get('related'),
    }));

    // Merge results with confidence weighting
    const mergedResults = {
      vector: vectorResults,
      graph: graphResults,
      query,
    };

    logger.info({ message: 'Hybrid search completed', query, resultCount: (vectorResults as any[]).length + graphResults.length });

    res.json(mergedResults);
  } catch (error) {
    next(error);
  }
});

// Semantic search only
router.post('/semantic', async (req, res, next) => {
  try {
    const { query, conversationId, limit = '10' } = req.body;

    const queryEmbedding = await generateEmbedding(query);

    const results = await prisma.$queryRaw`
      SELECT id, role, content, metadata, created_at,
             embedding <=> ${queryEmbedding}::vector as distance
      FROM messages
      WHERE conversation_id = ${conversationId}
      ORDER BY embedding <=> ${queryEmbedding}::vector
      LIMIT ${parseInt(limit)}
    `;

    res.json({ results, query, count: (results as any[]).length });
  } catch (error) {
    next(error);
  }
});

// Graph traversal search
router.post('/graph', async (req, res, next) => {
  try {
    const { entityId, depth = '2', limit = '20' } = req.body;

    const session = neo4jDriver.session();
    const result = await session.run(
      `
      MATCH path = (start:Entity {id: $entityId})-[*1..${depth}]-(connected)
      RETURN connected, length(path) as distance
      LIMIT $limit
      `,
      { entityId, limit: parseInt(limit) }
    );
    await session.close();

    const nodes = result.records.map((record) => ({
      entity: record.get('connected').properties,
      distance: record.get('distance').toNumber(),
    }));

    res.json({ nodes, entityId, depth });
  } catch (error) {
    next(error);
  }
});

export { router as retrieveRoutes };
