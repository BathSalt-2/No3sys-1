import { Router } from 'express';
import { prisma, openai } from '../index';
import { logger } from '../utils/logger';

const router = Router();

// Generate response
router.post('/', async (req, res, next) => {
  try {
    const { messages, context, mode = 'balanced', temperature = 0.7 } = req.body;

    // Mode-specific system prompts
    const systemPrompts: Record<string, string> = {
      analytic: 'You are a precise, analytical assistant. Focus on accuracy, logic, and structured reasoning.',
      creative: 'You are a creative, imaginative assistant. Think outside the box and offer novel perspectives.',
      empathetic: 'You are an empathetic, supportive assistant. Show understanding and emotional intelligence.',
      balanced: 'You are a balanced assistant, combining analytical rigor with creativity and empathy.',
    };

    const systemPrompt = systemPrompts[mode] || systemPrompts.balanced;

    const chatMessages = [
      { role: 'system', content: systemPrompt },
      ...(context ? [{ role: 'system', content: `Context: ${context}` }] : []),
      ...messages,
    ];

    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: chatMessages as any,
      temperature,
      max_tokens: 2000,
    });

    const generatedText = response.choices[0]?.message?.content || '';
    const usage = response.usage;

    // Log generation for analytics
    await prisma.generationLog.create({
      data: {
        mode,
        promptTokens: usage?.prompt_tokens || 0,
        completionTokens: usage?.completion_tokens || 0,
        totalTokens: usage?.total_tokens || 0,
        metadata: { temperature, messageCount: messages.length },
      },
    });

    logger.info({
      message: 'Response generated',
      mode,
      tokens: usage?.total_tokens,
    });

    res.json({
      response: generatedText,
      mode,
      usage,
    });
  } catch (error) {
    next(error);
  }
});

// Stream generation
router.post('/stream', async (req, res, next) => {
  try {
    const { messages, context, mode = 'balanced', temperature = 0.7 } = req.body;

    const systemPrompts: Record<string, string> = {
      analytic: 'You are a precise, analytical assistant.',
      creative: 'You are a creative, imaginative assistant.',
      empathetic: 'You are an empathetic, supportive assistant.',
      balanced: 'You are a balanced assistant.',
    };

    const chatMessages = [
      { role: 'system', content: systemPrompts[mode] },
      ...(context ? [{ role: 'system', content: `Context: ${context}` }] : []),
      ...messages,
    ];

    const stream = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: chatMessages as any,
      temperature,
      stream: true,
      max_tokens: 2000,
    });

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content || '';
      if (content) {
        res.write(`data: ${JSON.stringify({ content })}}\n\n`);
      }
    }

    res.write('data: [DONE]\n\n');
    res.end();
  } catch (error) {
    next(error);
  }
});

// Generate with retrieval augmentation
router.post('/rag', async (req, res, next) => {
  try {
    const { query, retrievedContext, mode = 'balanced' } = req.body;

    const systemPrompts: Record<string, string> = {
      analytic: 'You are an analytical assistant. Use the provided context to answer accurately.',
      creative: 'You are a creative assistant. Use the context as inspiration.',
      empathetic: 'You are an empathetic assistant. Use the context to provide helpful responses.',
      balanced: 'You are a balanced assistant. Use the provided context effectively.',
    };

    const contextText = retrievedContext
      .map((ctx: any, i: number) => `[${i + 1}] ${ctx.content || ctx}`)
      .join('\n\n');

    const messages = [
      { role: 'system', content: systemPrompts[mode] },
      {
        role: 'system',
        content: `Use the following retrieved context to answer the user's query:\n\n${contextText}`,
      },
      { role: 'user', content: query },
    ];

    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: messages as any,
      temperature: 0.5,
      max_tokens: 2000,
    });

    const generatedText = response.choices[0]?.message?.content || '';

    res.json({
      response: generatedText,
      mode,
      sourcesUsed: retrievedContext.length,
    });
  } catch (error) {
    next(error);
  }
});

export { router as generateRoutes };
