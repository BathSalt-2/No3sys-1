import { Router } from 'express';
import axios from 'axios';
import { redis, AGENT_URLS } from '../index';
import { logger } from '../utils/logger';

const router = Router();

// Mode definitions
const MODES = {
  analytic: {
    retriever: { limit: 10 },
    reasoner: { type: 'deductive' },
    generator: { mode: 'analytic', temperature: 0.2 },
  },
  creative: {
    retriever: { limit: 5 },
    reasoner: { type: 'abductive' },
    generator: { mode: 'creative', temperature: 0.9 },
  },
  empathetic: {
    retriever: { limit: 8 },
    reasoner: { type: 'abductive' },
    generator: { mode: 'empathetic', temperature: 0.6 },
  },
  balanced: {
    retriever: { limit: 10 },
    reasoner: { type: 'deductive' },
    generator: { mode: 'balanced', temperature: 0.5 },
  },
};

// Orchestrate all three agents
router.post('/orchestrate', async (req, res, next) => {
  try {
    const { query, conversationId, mode = 'balanced', context } = req.body;
    const modeConfig = MODES[mode as keyof typeof MODES] || MODES.balanced;

    const startTime = Date.now();
    const trace: any = { steps: [], mode };

    // Step 1: Retrieve relevant information
    logger.info({ message: 'Starting retrieval', query, mode });
    const retrievalStart = Date.now();
    
    const retrievalResponse = await axios.post(`${AGENT_URLS.retriever}/retrieve/hybrid`, {
      query,
      conversationId,
      limit: modeConfig.retriever.limit,
    });
    
    const retrievedContext = retrievalResponse.data;
    trace.steps.push({
      agent: 'retriever',
      duration: Date.now() - retrievalStart,
      results: {
        vector: (retrievedContext.vector as any[])?.length || 0,
        graph: (retrievedContext.graph as any[])?.length || 0,
      },
    });

    // Step 2: Reason over retrieved information
    logger.info({ message: 'Starting reasoning', query, mode });
    const reasoningStart = Date.now();
    
    const reasoningResponse = await axios.post(`${AGENT_URLS.reasoner}/reason/${modeConfig.reasoner.type}`, {
      premises: retrievedContext.vector?.map((v: any) => v.content) || [],
      question: query,
      context,
    });
    
    const reasoningResult = reasoningResponse.data;
    trace.steps.push({
      agent: 'reasoner',
      duration: Date.now() - reasoningStart,
      type: modeConfig.reasoner.type,
      traceId: reasoningResult.traceId,
    });

    // Step 3: Generate response
    logger.info({ message: 'Starting generation', query, mode });
    const generationStart = Date.now();
    
    const generationResponse = await axios.post(`${AGENT_URLS.generator}/generate/rag`, {
      query,
      retrievedContext: [
        ...(retrievedContext.vector || []),
        ...(retrievedContext.graph || []),
      ],
      mode: modeConfig.generator.mode,
    });
    
    const generatedResponse = generationResponse.data;
    trace.steps.push({
      agent: 'generator',
      duration: Date.now() - generationStart,
      mode: modeConfig.generator.mode,
    });

    // Calculate confidence-weighted fusion
    const totalDuration = Date.now() - startTime;
    trace.totalDuration = totalDuration;

    // Cache result
    await redis.setex(
      `orchestration:${conversationId}:${query}`,
      300,
      JSON.stringify({ response: generatedResponse.response, trace })
    );

    logger.info({
      message: 'Orchestration complete',
      query,
      mode,
      duration: totalDuration,
    });

    res.json({
      response: generatedResponse.response,
      mode,
      trace,
      sources: {
        vector: retrievedContext.vector?.length || 0,
        graph: retrievedContext.graph?.length || 0,
      },
    });
  } catch (error) {
    next(error);
  }
});

// Quick route (skip reasoning for speed)
router.post('/quick', async (req, res, next) => {
  try {
    const { query, conversationId, mode = 'balanced' } = req.body;

    // Parallel retrieval and generation
    const [retrievalResponse, generationResponse] = await Promise.all([
      axios.post(`${AGENT_URLS.retriever}/retrieve/semantic`, {
        query,
        conversationId,
        limit: 5,
      }),
      Promise.resolve(null), // Placeholder for potential pre-fetch
    ]);

    const retrievedContext = retrievalResponse.data.results;

    const generationResult = await axios.post(`${AGENT_URLS.generator}/generate/rag`, {
      query,
      retrievedContext,
      mode,
    });

    res.json({
      response: generationResult.data.response,
      mode,
      sources: retrievedContext.length,
    });
  } catch (error) {
    next(error);
  }
});

// Get available modes
router.get('/modes', (req, res) => {
  res.json({
    modes: Object.keys(MODES),
    descriptions: {
      analytic: 'Focuses on accuracy, logic, and structured reasoning',
      creative: 'Emphasizes novel perspectives and imaginative solutions',
      empathetic: 'Prioritizes understanding and emotional intelligence',
      balanced: 'Combines analytical rigor with creativity and empathy',
    },
  });
});

export { router as routerRoutes };
