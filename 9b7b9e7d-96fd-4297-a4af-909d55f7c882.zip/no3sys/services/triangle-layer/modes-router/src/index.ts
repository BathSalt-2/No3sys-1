import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import Redis from 'ioredis';
import { logger } from './utils/logger';
import { routerRoutes } from './routes/router';
import { errorHandler } from './middleware/error-handler';
import { requestId } from './middleware/request-id';

const app = express();
const port = process.env.PORT || 3023;

export const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

// Agent service URLs
export const AGENT_URLS = {
  retriever: process.env.RETRIEVER_AGENT_URL || 'http://localhost:3020',
  reasoner: process.env.REASONER_AGENT_URL || 'http://localhost:3021',
  generator: process.env.GENERATOR_AGENT_URL || 'http://localhost:3022',
};

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan('combined', { stream: { write: (msg) => logger.info(msg.trim()) } }));
app.use(requestId);

app.get('/health', async (req, res) => {
  try {
    await redis.ping();
    res.json({ status: 'healthy', service: 'modes-router' });
  } catch (error) {
    res.status(503).json({ status: 'unhealthy' });
  }
});

app.use('/route', routerRoutes);

app.use(errorHandler);

const gracefulShutdown = async () => {
  await redis.quit();
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

app.listen(port, () => {
  logger.info(`Modes Router running on port ${port}`);
  logger.info(`Agent URLs: ${JSON.stringify(AGENT_URLS)}`);
});
