import { Router } from 'express';
import { prisma, openai } from '../index';
import { logger } from '../utils/logger';

const router = Router();

// Deductive reasoning (general to specific)
router.post('/deductive', async (req, res, next) => {
  try {
    const { premises, question, context } = req.body;

    const prompt = `
Premises:
${premises.map((p: string, i: number) => `${i + 1}. ${p}`).join('\n')}

Context: ${context || 'None'}

Question: ${question}

Using deductive reasoning (general principles to specific conclusions), provide a logical answer. Structure your response as:
1. Identify the applicable premises
2. Apply logical rules
3. State the conclusion
4. Confidence level (0-1)
`;

    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'You are a deductive reasoning engine.' },
        { role: 'user', content: prompt },
      ],
      temperature: 0.2,
    });

    const result = response.choices[0]?.message?.content || '';

    // Store reasoning trace
    const trace = await prisma.reasoningTrace.create({
      data: {
        type: 'deductive',
        input: { premises, question, context },
        output: result,
        confidence: extractConfidence(result),
      },
    });

    res.json({ result, traceId: trace.id, type: 'deductive' });
  } catch (error) {
    next(error);
  }
});

// Inductive reasoning (specific to general)
router.post('/inductive', async (req, res, next) => {
  try {
    const { observations, context } = req.body;

    const prompt = `
Observations:
${observations.map((o: string, i: number) => `${i + 1}. ${o}`).join('\n')}

Context: ${context || 'None'}

Using inductive reasoning (specific observations to general patterns), identify patterns and form hypotheses. Structure your response as:
1. List observed patterns
2. Form general hypotheses
3. Assess confidence in each hypothesis (0-1)
4. Suggest what would confirm or refute
`;

    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'You are an inductive reasoning engine.' },
        { role: 'user', content: prompt },
      ],
      temperature: 0.3,
    });

    const result = response.choices[0]?.message?.content || '';

    const trace = await prisma.reasoningTrace.create({
      data: {
        type: 'inductive',
        input: { observations, context },
        output: result,
        confidence: extractConfidence(result),
      },
    });

    res.json({ result, traceId: trace.id, type: 'inductive' });
  } catch (error) {
    next(error);
  }
});

// Abductive reasoning (inference to best explanation)
router.post('/abductive', async (req, res, next) => {
  try {
    const { observations, possibleExplanations, context } = req.body;

    const prompt = `
Observations:
${observations.map((o: string, i: number) => `${i + 1}. ${o}`).join('\n')}

Possible Explanations:
${possibleExplanations?.map((e: string, i: number) => `${i + 1}. ${e}`).join('\n') || 'Generate plausible explanations'}

Context: ${context || 'None'}

Using abductive reasoning (inference to the best explanation), determine the most likely explanation. Structure your response as:
1. List all plausible explanations
2. Evaluate each against observations
3. Select best explanation with justification
4. Confidence level (0-1)
`;

    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'You are an abductive reasoning engine.' },
        { role: 'user', content: prompt },
      ],
      temperature: 0.4,
    });

    const result = response.choices[0]?.message?.content || '';

    const trace = await prisma.reasoningTrace.create({
      data: {
        type: 'abductive',
        input: { observations, possibleExplanations, context },
        output: result,
        confidence: extractConfidence(result),
      },
    });

    res.json({ result, traceId: trace.id, type: 'abductive' });
  } catch (error) {
    next(error);
  }
});

// Multi-step reasoning chain
router.post('/chain', async (req, res, next) => {
  try {
    const { steps, initialContext } = req.body;

    let currentContext = initialContext;
    const reasoningChain = [];

    for (const step of steps) {
      const prompt = `
Context: ${currentContext}

Step: ${step.question}

Provide a reasoned response and update the context for the next step.
`;

      const response = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You are a step-by-step reasoning engine.' },
          { role: 'user', content: prompt },
        ],
        temperature: 0.3,
      });

      const result = response.choices[0]?.message?.content || '';
      reasoningChain.push({ step: step.name, result });
      currentContext += `\n${step.name}: ${result}`;
    }

    const trace = await prisma.reasoningTrace.create({
      data: {
        type: 'chain',
        input: { steps, initialContext },
        output: reasoningChain,
        confidence: 0.8,
      },
    });

    res.json({ chain: reasoningChain, finalContext: currentContext, traceId: trace.id });
  } catch (error) {
    next(error);
  }
});

// Helper to extract confidence from text
function extractConfidence(text: string): number {
  const match = text.match(/confidence[\s:]*(0?\.\d+|1\.0|1)/i);
  return match ? parseFloat(match[1]) : 0.5;
}

export { router as reasonRoutes };
