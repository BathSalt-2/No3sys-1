import { Router } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { prisma, redis, openai } from '../index';
import { AppError } from '../middleware/error-handler';
import { logger } from '../utils/logger';

const router = Router();

// Generate embedding for message content
const generateEmbedding = async (content: string): Promise<number[]> => {
  try {
    const response = await openai.embeddings.create({
      model: 'text-embedding-3-small',
      input: content,
    });
    return response.data[0].embedding;
  } catch (error) {
    logger.error('Failed to generate embedding:', error);
    return [];
  }
};

// Create message
router.post('/', async (req, res, next) => {
  try {
    const { conversationId, role, content, metadata } = req.body;

    // Verify conversation exists
    const conversation = await prisma.conversation.findUnique({
      where: { id: conversationId },
    });

    if (!conversation) {
      throw new AppError(404, 'Conversation not found', 'CONVERSATION_NOT_FOUND');
    }

    // Generate embedding
    const embedding = await generateEmbedding(content);

    const message = await prisma.message.create({
      data: {
        id: uuidv4(),
        conversationId,
        role,
        content,
        embedding: embedding.length > 0 ? embedding : undefined,
        metadata: metadata || {},
      },
    });

    // Update conversation timestamp
    await prisma.conversation.update({
      where: { id: conversationId },
      data: { updatedAt: new Date() },
    });

    // Invalidate cache
    await redis.del(`conversation:${conversationId}`);

    logger.info({ message: 'Message created', messageId: message.id, conversationId });

    res.status(201).json(message);
  } catch (error) {
    next(error);
  }
});

// Get messages for conversation
router.get('/conversation/:conversationId', async (req, res, next) => {
  try {
    const { conversationId } = req.params;
    const { limit = '50', offset = '0' } = req.query;

    const messages = await prisma.message.findMany({
      where: { conversationId },
      orderBy: { createdAt: 'asc' },
      take: parseInt(limit as string),
      skip: parseInt(offset as string),
    });

    const total = await prisma.message.count({ where: { conversationId } });

    res.json({ messages, total });
  } catch (error) {
    next(error);
  }
});

// Semantic search within conversation
router.post('/search', async (req, res, next) => {
  try {
    const { conversationId, query, limit = '10' } = req.body;

    const queryEmbedding = await generateEmbedding(query);

    if (queryEmbedding.length === 0) {
      throw new AppError(500, 'Failed to generate query embedding', 'EMBEDDING_ERROR');
    }

    // Use pgvector for similarity search
    const messages = await prisma.$queryRaw`
      SELECT id, role, content, metadata, created_at,
             embedding <=> ${queryEmbedding}::vector as distance
      FROM messages
      WHERE conversation_id = ${conversationId}
      ORDER BY embedding <=> ${queryEmbedding}::vector
      LIMIT ${parseInt(limit)}
    `;

    res.json({ messages, query });
  } catch (error) {
    next(error);
  }
});

// Update message
router.patch('/:messageId', async (req, res, next) => {
  try {
    const { messageId } = req.params;
    const { content, metadata } = req.body;

    let embedding;
    if (content) {
      embedding = await generateEmbedding(content);
    }

    const updated = await prisma.message.update({
      where: { id: messageId },
      data: {
        content: content || undefined,
        embedding: embedding && embedding.length > 0 ? embedding : undefined,
        metadata: metadata ? { ...metadata } : undefined,
        isEdited: true,
        editedAt: new Date(),
      },
    });

    // Invalidate cache
    await redis.del(`conversation:${updated.conversationId}`);

    res.json(updated);
  } catch (error) {
    next(error);
  }
});

export { router as messageRoutes };
