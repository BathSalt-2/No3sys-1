import { Router } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { prisma, redis } from '../index';
import { AppError } from '../middleware/error-handler';
import { logger } from '../utils/logger';

const router = Router();

// Create conversation
router.post('/', async (req, res, next) => {
  try {
    const { userId, sessionId, title, metadata } = req.body;

    const conversation = await prisma.conversation.create({
      data: {
        id: uuidv4(),
        userId,
        sessionId,
        title: title || 'New Conversation',
        metadata: metadata || {},
      },
    });

    await redis.setex(`conversation:${conversation.id}`, 3600, JSON.stringify(conversation));

    logger.info({ message: 'Conversation created', conversationId: conversation.id });

    res.status(201).json(conversation);
  } catch (error) {
    next(error);
  }
});

// Get conversation
router.get('/:conversationId', async (req, res, next) => {
  try {
    const { conversationId } = req.params;

    const cached = await redis.get(`conversation:${conversationId}`);
    if (cached) {
      return res.json(JSON.parse(cached));
    }

    const conversation = await prisma.conversation.findUnique({
      where: { id: conversationId },
      include: { messages: { orderBy: { createdAt: 'asc' } } },
    });

    if (!conversation) {
      throw new AppError(404, 'Conversation not found', 'CONVERSATION_NOT_FOUND');
    }

    await redis.setex(`conversation:${conversationId}`, 3600, JSON.stringify(conversation));

    res.json(conversation);
  } catch (error) {
    next(error);
  }
});

// List conversations
router.get('/user/:userId', async (req, res, next) => {
  try {
    const { userId } = req.params;
    const { limit = '20', offset = '0' } = req.query;

    const conversations = await prisma.conversation.findMany({
      where: { userId },
      orderBy: { updatedAt: 'desc' },
      take: parseInt(limit as string),
      skip: parseInt(offset as string),
    });

    const total = await prisma.conversation.count({ where: { userId } });

    res.json({ conversations, total });
  } catch (error) {
    next(error);
  }
});

// Update conversation
router.patch('/:conversationId', async (req, res, next) => {
  try {
    const { conversationId } = req.params;
    const { title, metadata } = req.body;

    const updated = await prisma.conversation.update({
      where: { id: conversationId },
      data: {
        title: title || undefined,
        metadata: metadata ? { ...metadata } : undefined,
      },
    });

    await redis.setex(`conversation:${conversationId}`, 3600, JSON.stringify(updated));

    res.json(updated);
  } catch (error) {
    next(error);
  }
});

// Delete conversation
router.delete('/:conversationId', async (req, res, next) => {
  try {
    const { conversationId } = req.params;

    await prisma.conversation.delete({ where: { id: conversationId } });
    await redis.del(`conversation:${conversationId}`);

    res.json({ message: 'Conversation deleted' });
  } catch (error) {
    next(error);
  }
});

export { router as conversationRoutes };
