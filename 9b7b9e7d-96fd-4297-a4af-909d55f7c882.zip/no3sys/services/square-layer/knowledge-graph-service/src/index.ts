import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import neo4j from 'neo4j-driver';
import { Kafka } from 'kafkajs';
import { logger } from './utils/logger';
import { entityRoutes } from './routes/entities';
import { relationshipRoutes } from './routes/relationships';
import { queryRoutes } from './routes/queries';
import { errorHandler } from './middleware/error-handler';
import { requestId } from './middleware/request-id';

const app = express();
const port = process.env.PORT || 3004;

// Initialize Neo4j driver
export const neo4jDriver = neo4j.driver(
  process.env.NEO4J_URI || 'bolt://localhost:7687',
  neo4j.auth.basic(
    process.env.NEO4J_USER || 'neo4j',
    process.env.NEO4J_PASSWORD || 'password'
  )
);

// Initialize Kafka
const kafka = new Kafka({
  clientId: 'knowledge-graph-service',
  brokers: (process.env.KAFKA_BROKERS || 'localhost:9092').split(','),
});

export const kafkaConsumer = kafka.consumer({ groupId: 'knowledge-graph' });
export const kafkaProducer = kafka.producer();

// Connect to Kafka
const connectKafka = async () => {
  try {
    await kafkaProducer.connect();
    await kafkaConsumer.connect();
    
    // Subscribe to entity extraction events
    await kafkaConsumer.subscribe({ topic: 'entity-extracted', fromBeginning: false });
    
    await kafkaConsumer.run({
      eachMessage: async ({ topic, partition, message }) => {
        try {
          const data = JSON.parse(message.value?.toString() || '{}');
          logger.info({ message: 'Processing entity extraction', data });
          // Process entity extraction
        } catch (error) {
          logger.error('Error processing message:', error);
        }
      },
    });
    
    logger.info('Connected to Kafka');
  } catch (error) {
    logger.error('Failed to connect to Kafka:', error);
  }
};

connectKafka();

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan('combined', { stream: { write: (msg) => logger.info(msg.trim()) } }));
app.use(requestId);

// Health check
app.get('/health', async (req, res) => {
  try {
    const session = neo4jDriver.session();
    await session.run('RETURN 1');
    await session.close();
    res.json({ status: 'healthy', service: 'knowledge-graph-service' });
  } catch (error) {
    res.status(503).json({ status: 'unhealthy', error: 'Neo4j connection failed' });
  }
});

// Routes
app.use('/entities', entityRoutes);
app.use('/relationships', relationshipRoutes);
app.use('/queries', queryRoutes);

// Error handling
app.use(errorHandler);

// Graceful shutdown
const gracefulShutdown = async () => {
  await kafkaConsumer.disconnect();
  await kafkaProducer.disconnect();
  await neo4jDriver.close();
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

app.listen(port, () => {
  logger.info(`Knowledge Graph Service running on port ${port}`);
});
