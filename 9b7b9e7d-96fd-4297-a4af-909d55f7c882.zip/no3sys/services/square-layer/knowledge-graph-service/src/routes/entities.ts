import { Router } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { neo4jDriver, kafkaProducer } from '../index';
import { AppError } from '../middleware/error-handler';
import { logger } from '../utils/logger';

const router = Router();

// Create entity
router.post('/', async (req, res, next) => {
  const session = neo4jDriver.session();
  try {
    const { type, name, properties = {}, source, confidence = 1.0 } = req.body;
    const id = uuidv4();

    const result = await session.run(
      `
      CREATE (e:Entity {id: $id, type: $type, name: $name, createdAt: datetime()})
      SET e += $properties
      SET e.source = $source
      SET e.confidence = $confidence
      RETURN e
      `,
      { id, type, name, properties, source, confidence }
    );

    const entity = result.records[0]?.get('e').properties;

    // Emit event
    await kafkaProducer.send({
      topic: 'entity-created',
      messages: [{ key: id, value: JSON.stringify({ id, type, name, source }) }],
    });

    logger.info({ message: 'Entity created', entityId: id, type, name });

    res.status(201).json(entity);
  } catch (error) {
    next(error);
  } finally {
    await session.close();
  }
});

// Get entity by ID
router.get('/:id', async (req, res, next) => {
  const session = neo4jDriver.session();
  try {
    const { id } = req.params;

    const result = await session.run(
      `
      MATCH (e:Entity {id: $id})
      OPTIONAL MATCH (e)-[r]->(related:Entity)
      RETURN e, collect({relationship: r, entity: related}) as relationships
      `,
      { id }
    );

    if (result.records.length === 0) {
      throw new AppError(404, 'Entity not found', 'ENTITY_NOT_FOUND');
    }

    const entity = result.records[0].get('e').properties;
    const relationships = result.records[0].get('relationships');

    res.json({ ...entity, relationships });
  } catch (error) {
    next(error);
  } finally {
    await session.close();
  }
});

// Search entities
router.get('/', async (req, res, next) => {
  const session = neo4jDriver.session();
  try {
    const { q, type, limit = '20' } = req.query;

    let query = 'MATCH (e:Entity)';
    const params: any = {};
    const whereConditions: string[] = [];

    if (q) {
      whereConditions.push('e.name CONTAINS $searchTerm');
      params.searchTerm = q;
    }

    if (type) {
      whereConditions.push('e.type = $type');
      params.type = type;
    }

    if (whereConditions.length > 0) {
      query += ' WHERE ' + whereConditions.join(' AND ');
    }

    query += ' RETURN e LIMIT $limit';
    params.limit = parseInt(limit as string);

    const result = await session.run(query, params);
    const entities = result.records.map((record) => record.get('e').properties);

    res.json({ entities, count: entities.length });
  } catch (error) {
    next(error);
  } finally {
    await session.close();
  }
});

// Update entity
router.patch('/:id', async (req, res, next) => {
  const session = neo4jDriver.session();
  try {
    const { id } = req.params;
    const { name, properties } = req.body;

    const result = await session.run(
      `
      MATCH (e:Entity {id: $id})
      SET e.name = coalesce($name, e.name)
      SET e += $properties
      SET e.updatedAt = datetime()
      RETURN e
      `,
      { id, name, properties: properties || {} }
    );

    if (result.records.length === 0) {
      throw new AppError(404, 'Entity not found', 'ENTITY_NOT_FOUND');
    }

    res.json(result.records[0].get('e').properties);
  } catch (error) {
    next(error);
  } finally {
    await session.close();
  }
});

// Delete entity
router.delete('/:id', async (req, res, next) => {
  const session = neo4jDriver.session();
  try {
    const { id } = req.params;

    await session.run(
      `
      MATCH (e:Entity {id: $id})
      DETACH DELETE e
      `,
      { id }
    );

    res.json({ message: 'Entity deleted' });
  } catch (error) {
    next(error);
  } finally {
    await session.close();
  }
});

// Merge entities (deduplication)
router.post('/merge', async (req, res, next) => {
  const session = neo4jDriver.session();
  try {
    const { sourceIds, targetId } = req.body;

    await session.run(
      `
      MATCH (target:Entity {id: $targetId})
      MATCH (source:Entity) WHERE source.id IN $sourceIds
      WITH target, source
      MATCH (source)-[r]->(other)
      MERGE (target)-[r2:RELATED]->(other)
      SET r2 += properties(r)
      WITH source
      DETACH DELETE source
      `,
      { targetId, sourceIds }
    );

    logger.info({ message: 'Entities merged', targetId, sourceIds });

    res.json({ message: 'Entities merged successfully', targetId });
  } catch (error) {
    next(error);
  } finally {
    await session.close();
  }
});

export { router as entityRoutes };
