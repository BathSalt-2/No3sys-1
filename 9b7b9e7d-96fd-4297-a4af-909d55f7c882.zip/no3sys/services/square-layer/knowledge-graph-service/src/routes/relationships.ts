import { Router } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { neo4jDriver } from '../index';
import { AppError } from '../middleware/error-handler';
import { logger } from '../utils/logger';

const router = Router();

// Create relationship
router.post('/', async (req, res, next) => {
  const session = neo4jDriver.session();
  try {
    const { fromId, toId, type, properties = {}, confidence = 1.0 } = req.body;
    const id = uuidv4();

    const result = await session.run(
      `
      MATCH (from:Entity {id: $fromId})
      MATCH (to:Entity {id: $toId})
      CREATE (from)-[r:${type} {id: $id, createdAt: datetime()}]->(to)
      SET r += $properties
      SET r.confidence = $confidence
      RETURN r, from, to
      `,
      { id, fromId, toId, properties, confidence }
    );

    if (result.records.length === 0) {
      throw new AppError(404, 'One or both entities not found', 'ENTITIES_NOT_FOUND');
    }

    const relationship = result.records[0].get('r').properties;
    const from = result.records[0].get('from').properties;
    const to = result.records[0].get('to').properties;

    logger.info({
      message: 'Relationship created',
      relationshipId: id,
      from: from.name,
      to: to.name,
      type,
    });

    res.status(201).json({ ...relationship, from, to });
  } catch (error) {
    next(error);
  } finally {
    await session.close();
  }
});

// Get relationship by ID
router.get('/:id', async (req, res, next) => {
  const session = neo4jDriver.session();
  try {
    const { id } = req.params;

    const result = await session.run(
      `
      MATCH (from)-[r {id: $id}]->(to)
      RETURN r, from, to
      `,
      { id }
    );

    if (result.records.length === 0) {
      throw new AppError(404, 'Relationship not found', 'RELATIONSHIP_NOT_FOUND');
    }

    const relationship = result.records[0].get('r').properties;
    const from = result.records[0].get('from').properties;
    const to = result.records[0].get('to').properties;

    res.json({ ...relationship, from, to });
  } catch (error) {
    next(error);
  } finally {
    await session.close();
  }
});

// Get entity relationships
router.get('/entity/:entityId', async (req, res, next) => {
  const session = neo4jDriver.session();
  try {
    const { entityId } = req.params;
    const { direction = 'both' } = req.query;

    let query = '';
    if (direction === 'outgoing') {
      query = `
        MATCH (e:Entity {id: $entityId})-[r]->(other)
        RETURN r, other, 'outgoing' as direction
      `;
    } else if (direction === 'incoming') {
      query = `
        MATCH (e:Entity {id: $entityId})<-[r]-(other)
        RETURN r, other, 'incoming' as direction
      `;
    } else {
      query = `
        MATCH (e:Entity {id: $entityId})
        OPTIONAL MATCH (e)-[r1]->(outgoing)
        OPTIONAL MATCH (e)<-[r2]-(incoming)
        RETURN r1 as r, outgoing as other, 'outgoing' as direction
        UNION
        MATCH (e:Entity {id: $entityId})
        OPTIONAL MATCH (e)<-[r2]-(incoming)
        RETURN r2 as r, incoming as other, 'incoming' as direction
      `;
    }

    const result = await session.run(query, { entityId });
    const relationships = result.records.map((record) => ({
      ...record.get('r').properties,
      other: record.get('other')?.properties,
      direction: record.get('direction'),
    }));

    res.json({ relationships, count: relationships.length });
  } catch (error) {
    next(error);
  } finally {
    await session.close();
  }
});

// Update relationship
router.patch('/:id', async (req, res, next) => {
  const session = neo4jDriver.session();
  try {
    const { id } = req.params;
    const { properties } = req.body;

    const result = await session.run(
      `
      MATCH ()-[r {id: $id}]->()
      SET r += $properties
      SET r.updatedAt = datetime()
      RETURN r
      `,
      { id, properties: properties || {} }
    );

    if (result.records.length === 0) {
      throw new AppError(404, 'Relationship not found', 'RELATIONSHIP_NOT_FOUND');
    }

    res.json(result.records[0].get('r').properties);
  } catch (error) {
    next(error);
  } finally {
    await session.close();
  }
});

// Delete relationship
router.delete('/:id', async (req, res, next) => {
  const session = neo4jDriver.session();
  try {
    const { id } = req.params;

    await session.run(
      `
      MATCH ()-[r {id: $id}]->()
      DELETE r
      `,
      { id }
    );

    res.json({ message: 'Relationship deleted' });
  } catch (error) {
    next(error);
  } finally {
    await session.close();
  }
});

export { router as relationshipRoutes };
