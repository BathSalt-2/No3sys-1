import { Router } from 'express';
import { neo4jDriver } from '../index';
import { logger } from '../utils/logger';

const router = Router();

// Path finding between entities
router.post('/path', async (req, res, next) => {
  const session = neo4jDriver.session();
  try {
    const { fromId, toId, maxDepth = 4 } = req.body;

    const result = await session.run(
      `
      MATCH path = shortestPath(
        (from:Entity {id: $fromId})-[*..${maxDepth}]-(to:Entity {id: $toId})
      )
      RETURN path
      `,
      { fromId, toId }
    );

    if (result.records.length === 0) {
      return res.json({ path: null, message: 'No path found' });
    }

    const path = result.records[0].get('path');
    const nodes = path.segments.map((s: any) => s.start.properties);
    nodes.push(path.end.properties);
    const relationships = path.segments.map((s: any) => ({
      ...s.relationship.properties,
      type: s.relationship.type,
    }));

    res.json({
      path: {
        nodes,
        relationships,
        length: path.length,
      },
    });
  } catch (error) {
    next(error);
  } finally {
    await session.close();
  }
});

// Graph centrality analysis
router.post('/centrality', async (req, res, next) => {
  const session = neo4jDriver.session();
  try {
    const { type, limit = '20' } = req.body;

    let query = '';
    if (type === 'degree') {
      query = `
        MATCH (e:Entity)
        OPTIONAL MATCH (e)-[r]-()
        WITH e, count(r) as degree
        RETURN e, degree
        ORDER BY degree DESC
        LIMIT $limit
      `;
    } else if (type === 'betweenness') {
      query = `
        CALL gds.betweenness.stream('entity-graph')
        YIELD nodeId, score
        MATCH (e:Entity) WHERE id(e) = nodeId
        RETURN e, score
        ORDER BY score DESC
        LIMIT $limit
      `;
    } else {
      query = `
        MATCH (e:Entity)
        OPTIONAL MATCH (e)-[r]-()
        WITH e, count(r) as degree
        RETURN e, degree
        ORDER BY degree DESC
        LIMIT $limit
      `;
    }

    const result = await session.run(query, { limit: parseInt(limit) });
    const nodes = result.records.map((record) => ({
      entity: record.get('e').properties,
      score: record.get('degree') || record.get('score'),
    }));

    res.json({ centrality: type, nodes });
  } catch (error) {
    next(error);
  } finally {
    await session.close();
  }
});

// Community detection
router.post('/communities', async (req, res, next) => {
  const session = neo4jDriver.session();
  try {
    const { algorithm = 'louvain' } = req.body;

    let query = '';
    if (algorithm === 'louvain') {
      query = `
        CALL gds.louvain.stream('entity-graph')
        YIELD nodeId, communityId
        MATCH (e:Entity) WHERE id(e) = nodeId
        RETURN communityId, collect(e) as entities
        ORDER BY size(entities) DESC
      `;
    } else if (algorithm === 'wcc') {
      query = `
        CALL gds.wcc.stream('entity-graph')
        YIELD nodeId, componentId
        MATCH (e:Entity) WHERE id(e) = nodeId
        RETURN componentId as communityId, collect(e) as entities
        ORDER BY size(entities) DESC
      `;
    }

    const result = await session.run(query);
    const communities = result.records.map((record) => ({
      id: record.get('communityId').toString(),
      entities: record.get('entities').map((e: any) => e.properties),
      size: record.get('entities').length,
    }));

    res.json({ algorithm, communities, count: communities.length });
  } catch (error) {
    next(error);
  } finally {
    await session.close();
  }
});

// Similarity search
router.post('/similar', async (req, res, next) => {
  const session = neo4jDriver.session();
  try {
    const { entityId, limit = '10' } = req.body;

    const result = await session.run(
      `
      MATCH (e:Entity {id: $entityId})
      MATCH (other:Entity)
      WHERE other <> e
      OPTIONAL MATCH (e)-[r1]-(common)-[r2]-(other)
      WITH e, other, count(common) as commonNeighbors
      ORDER BY commonNeighbors DESC
      LIMIT $limit
      RETURN other, commonNeighbors
      `,
      { entityId, limit: parseInt(limit) }
    );

    const similar = result.records.map((record) => ({
      entity: record.get('other').properties,
      commonNeighbors: record.get('commonNeighbors').toNumber(),
    }));

    res.json({ entityId, similar });
  } catch (error) {
    next(error);
  } finally {
    await session.close();
  }
});

// Custom Cypher query (admin only)
router.post('/cypher', async (req, res, next) => {
  const session = neo4jDriver.session();
  try {
    const { query, params = {} } = req.body;

    // Basic security: only allow read queries
    const normalizedQuery = query.trim().toLowerCase();
    if (
      normalizedQuery.includes('create') ||
      normalizedQuery.includes('merge') ||
      normalizedQuery.includes('delete') ||
      normalizedQuery.includes('set') ||
      normalizedQuery.includes('remove')
    ) {
      throw new Error('Only read queries are allowed');
    }

    const result = await session.run(query, params);
    const records = result.records.map((record) => {
      const obj: any = {};
      record.keys.forEach((key) => {
        const value = record.get(key);
        obj[key] = value?.properties || value;
      });
      return obj;
    });

    res.json({ records, count: records.length });
  } catch (error) {
    next(error);
  } finally {
    await session.close();
  }
});

export { router as queryRoutes };
