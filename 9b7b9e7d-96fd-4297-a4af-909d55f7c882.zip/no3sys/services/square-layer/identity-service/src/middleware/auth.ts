import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { prisma, redis } from '../index';
import { AppError } from './error-handler';
import { logger } from '../utils/logger';

interface TokenPayload {
  userId: string;
  email: string;
  type: 'access' | 'refresh';
}

declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        email: string;
      };
    }
  }
}

const JWT_SECRET = process.env.JWT_SECRET || 'no3sys_jwt_secret_key';
const ACCESS_TOKEN_EXPIRY = '15m';
const REFRESH_TOKEN_EXPIRY = '7d';

export const generateTokens = (userId: string, email: string) => {
  const accessToken = jwt.sign(
    { userId, email, type: 'access' },
    JWT_SECRET,
    { expiresIn: ACCESS_TOKEN_EXPIRY }
  );

  const refreshToken = jwt.sign(
    { userId, email, type: 'refresh' },
    JWT_SECRET,
    { expiresIn: REFRESH_TOKEN_EXPIRY }
  );

  return { accessToken, refreshToken };
};

export const verifyToken = (token: string): TokenPayload => {
  return jwt.verify(token, JWT_SECRET) as TokenPayload;
};

export const authenticate = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new AppError(401, 'Authentication required', 'UNAUTHORIZED');
    }

    const token = authHeader.substring(7);
    
    // Check if token is blacklisted
    const isBlacklisted = await redis.get(`blacklist:${token}`);
    if (isBlacklisted) {
      throw new AppError(401, 'Token has been revoked', 'TOKEN_REVOKED');
    }

    const payload = verifyToken(token);
    
    if (payload.type !== 'access') {
      throw new AppError(401, 'Invalid token type', 'INVALID_TOKEN_TYPE');
    }

    // Verify user still exists and is active
    const user = await prisma.user.findUnique({
      where: { id: payload.userId },
      select: { id: true, email: true, isActive: true },
    });

    if (!user) {
      throw new AppError(401, 'User not found', 'USER_NOT_FOUND');
    }

    if (!user.isActive) {
      throw new AppError(401, 'Account is deactivated', 'ACCOUNT_DEACTIVATED');
    }

    req.user = { id: user.id, email: user.email };
    next();
  } catch (error) {
    if (error instanceof AppError) {
      return next(error);
    }
    if (error instanceof jwt.TokenExpiredError) {
      return next(new AppError(401, 'Token has expired', 'TOKEN_EXPIRED'));
    }
    if (error instanceof jwt.JsonWebTokenError) {
      return next(new AppError(401, 'Invalid token', 'INVALID_TOKEN'));
    }
    next(error);
  }
};

export const optionalAuth = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return next();
    }

    const token = authHeader.substring(7);
    const isBlacklisted = await redis.get(`blacklist:${token}`);
    
    if (isBlacklisted) {
      return next();
    }

    const payload = verifyToken(token);
    
    if (payload.type === 'access') {
      const user = await prisma.user.findUnique({
        where: { id: payload.userId },
        select: { id: true, email: true, isActive: true },
      });

      if (user && user.isActive) {
        req.user = { id: user.id, email: user.email };
      }
    }
    
    next();
  } catch (error) {
    // Silently ignore auth errors for optional auth
    next();
  }
};

export const requireApiKey = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const apiKey = req.headers['x-api-key'] as string;
    
    if (!apiKey) {
      throw new AppError(401, 'API key required', 'API_KEY_REQUIRED');
    }

    // Hash the provided key and look it up
    const crypto = await import('crypto');
    const keyHash = crypto.createHash('sha256').update(apiKey).digest('hex');

    const keyRecord = await prisma.apiKey.findUnique({
      where: { keyHash },
      include: { user: true },
    });

    if (!keyRecord) {
      throw new AppError(401, 'Invalid API key', 'INVALID_API_KEY');
    }

    if (!keyRecord.isActive) {
      throw new AppError(401, 'API key is deactivated', 'API_KEY_DEACTIVATED');
    }

    if (keyRecord.expiresAt && keyRecord.expiresAt < new Date()) {
      throw new AppError(401, 'API key has expired', 'API_KEY_EXPIRED');
    }

    // Update last used
    await prisma.apiKey.update({
      where: { id: keyRecord.id },
      data: { lastUsedAt: new Date() },
    });

    req.user = { id: keyRecord.user.id, email: keyRecord.user.email };
    next();
  } catch (error) {
    next(error);
  }
};
