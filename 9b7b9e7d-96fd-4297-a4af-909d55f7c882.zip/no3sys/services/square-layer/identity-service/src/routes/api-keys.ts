import { Router } from 'express';
import { body, validationResult } from 'express-validator';
import crypto from 'crypto';
import { prisma } from '../index';
import { authenticate } from '../middleware/auth';
import { AppError } from '../middleware/error-handler';
import { logger } from '../utils/logger';

const router = Router();

// Validation middleware
const validate = (req: any, res: any, next: any) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    throw new AppError(400, 'Validation failed', 'VALIDATION_ERROR', {
      errors: errors.array(),
    });
  }
  next();
};

// Generate API key
const generateApiKey = (): string => {
  return `no3sys_${crypto.randomBytes(32).toString('hex')}`;
};

// Hash API key
const hashApiKey = (key: string): string => {
  return crypto.createHash('sha256').update(key).digest('hex');
};

// List API keys
router.get('/', authenticate, async (req, res, next) => {
  try {
    const keys = await prisma.apiKey.findMany({
      where: {
        userId: req.user!.id,
        isActive: true,
      },
      select: {
        id: true,
        name: true,
        permissions: true,
        lastUsedAt: true,
        expiresAt: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    res.json({ keys });
  } catch (error) {
    next(error);
  }
});

// Create API key
router.post(
  '/',
  authenticate,
  [
    body('name').trim().isLength({ min: 1, max: 100 }),
    body('permissions').optional().isArray(),
    body('expiresInDays').optional().isInt({ min: 1, max: 365 }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { name, permissions = [], expiresInDays } = req.body;

      // Generate key (only shown once)
      const apiKey = generateApiKey();
      const keyHash = hashApiKey(apiKey);

      // Calculate expiration
      const expiresAt = expiresInDays
        ? new Date(Date.now() + expiresInDays * 24 * 60 * 60 * 1000)
        : null;

      // Store key
      const keyRecord = await prisma.apiKey.create({
        data: {
          userId: req.user!.id,
          name,
          keyHash,
          permissions,
          expiresAt,
        },
        select: {
          id: true,
          name: true,
          permissions: true,
          expiresAt: true,
          createdAt: true,
        },
      });

      logger.info({
        message: 'API key created',
        userId: req.user!.id,
        keyId: keyRecord.id,
      });

      // Return the key (only time it's shown)
      res.status(201).json({
        key: apiKey,
        ...keyRecord,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Revoke API key
router.delete('/:keyId', authenticate, async (req, res, next) => {
  try {
    const { keyId } = req.params;

    const key = await prisma.apiKey.findFirst({
      where: {
        id: keyId,
        userId: req.user!.id,
      },
    });

    if (!key) {
      throw new AppError(404, 'API key not found', 'API_KEY_NOT_FOUND');
    }

    await prisma.apiKey.update({
      where: { id: keyId },
      data: { isActive: false },
    });

    logger.info({
      message: 'API key revoked',
      userId: req.user!.id,
      keyId,
    });

    res.json({ message: 'API key revoked' });
  } catch (error) {
    next(error);
  }
});

// Update API key permissions
router.patch(
  '/:keyId',
  authenticate,
  [body('name').optional().trim(), body('permissions').optional().isArray()],
  async (req, res, next) => {
    try {
      const { keyId } = req.params;
      const { name, permissions } = req.body;

      const key = await prisma.apiKey.findFirst({
        where: {
          id: keyId,
          userId: req.user!.id,
        },
      });

      if (!key) {
        throw new AppError(404, 'API key not found', 'API_KEY_NOT_FOUND');
      }

      const updated = await prisma.apiKey.update({
        where: { id: keyId },
        data: {
          name: name || undefined,
          permissions: permissions || undefined,
        },
        select: {
          id: true,
          name: true,
          permissions: true,
          lastUsedAt: true,
          expiresAt: true,
          createdAt: true,
        },
      });

      res.json(updated);
    } catch (error) {
      next(error);
    }
  }
);

export { router as apiKeyRoutes };
