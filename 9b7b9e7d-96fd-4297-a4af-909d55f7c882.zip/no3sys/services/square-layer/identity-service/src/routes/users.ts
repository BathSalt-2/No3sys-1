import { Router } from 'express';
import { body, validationResult } from 'express-validator';
import { prisma } from '../index';
import { authenticate } from '../middleware/auth';
import { AppError } from '../middleware/error-handler';
import { logger } from '../utils/logger';

const router = Router();

// Validation middleware
const validate = (req: any, res: any, next: any) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    throw new AppError(400, 'Validation failed', 'VALIDATION_ERROR', {
      errors: errors.array(),
    });
  }
  next();
};

// Get user by username (public)
router.get('/:username', async (req, res, next) => {
  try {
    const { username } = req.params;

    const user = await prisma.user.findUnique({
      where: { username },
      select: {
        id: true,
        username: true,
        displayName: true,
        avatarUrl: true,
        createdAt: true,
      },
    });

    if (!user) {
      throw new AppError(404, 'User not found', 'USER_NOT_FOUND');
    }

    res.json(user);
  } catch (error) {
    next(error);
  }
});

// Update profile
router.patch(
  '/me',
  authenticate,
  [
    body('displayName').optional().trim().isLength({ max: 100 }),
    body('avatarUrl').optional().isURL(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { displayName, avatarUrl } = req.body;

      const user = await prisma.user.update({
        where: { id: req.user!.id },
        data: {
          displayName,
          avatarUrl,
        },
        select: {
          id: true,
          email: true,
          username: true,
          displayName: true,
          avatarUrl: true,
          updatedAt: true,
        },
      });

      logger.info({
        message: 'User profile updated',
        userId: user.id,
      });

      res.json(user);
    } catch (error) {
      next(error);
    }
  }
);

// Get user preferences
router.get('/me/preferences', authenticate, async (req, res, next) => {
  try {
    const preferences = await prisma.userPreferences.findUnique({
      where: { userId: req.user!.id },
    });

    if (!preferences) {
      throw new AppError(404, 'Preferences not found', 'PREFERENCES_NOT_FOUND');
    }

    res.json(preferences);
  } catch (error) {
    next(error);
  }
});

// Update preferences
router.patch(
  '/me/preferences',
  authenticate,
  async (req, res, next) => {
    try {
      const { theme, language, timezone, notifications, privacy, metadata } = req.body;

      const preferences = await prisma.userPreferences.update({
        where: { userId: req.user!.id },
        data: {
          theme,
          language,
          timezone,
          notifications: notifications ? { ...notifications } : undefined,
          privacy: privacy ? { ...privacy } : undefined,
          metadata: metadata ? { ...metadata } : undefined,
        },
      });

      logger.info({
        message: 'User preferences updated',
        userId: req.user!.id,
      });

      res.json(preferences);
    } catch (error) {
      next(error);
    }
  }
);

// Get active sessions
router.get('/me/sessions', authenticate, async (req, res, next) => {
  try {
    const sessions = await prisma.session.findMany({
      where: {
        userId: req.user!.id,
        expiresAt: { gt: new Date() },
      },
      select: {
        id: true,
        ipAddress: true,
        userAgent: true,
        createdAt: true,
        lastUsedAt: true,
        expiresAt: true,
      },
      orderBy: { lastUsedAt: 'desc' },
    });

    res.json({ sessions });
  } catch (error) {
    next(error);
  }
});

// Revoke specific session
router.delete('/me/sessions/:sessionId', authenticate, async (req, res, next) => {
  try {
    const { sessionId } = req.params;

    const session = await prisma.session.findFirst({
      where: {
        id: sessionId,
        userId: req.user!.id,
      },
    });

    if (!session) {
      throw new AppError(404, 'Session not found', 'SESSION_NOT_FOUND');
    }

    await prisma.session.delete({
      where: { id: sessionId },
    });

    // Blacklist token
    const { redis } = await import('../index');
    await redis.setex(`blacklist:${session.token}`, 900, 'true');

    logger.info({
      message: 'Session revoked',
      userId: req.user!.id,
      sessionId,
    });

    res.json({ message: 'Session revoked' });
  } catch (error) {
    next(error);
  }
});

// Deactivate account
router.post('/me/deactivate', authenticate, async (req, res, next) => {
  try {
    // Deactivate user
    await prisma.user.update({
      where: { id: req.user!.id },
      data: { isActive: false },
    });

    // Delete all sessions
    await prisma.session.deleteMany({
      where: { userId: req.user!.id },
    });

    logger.info({
      message: 'User account deactivated',
      userId: req.user!.id,
    });

    res.json({ message: 'Account deactivated successfully' });
  } catch (error) {
    next(error);
  }
});

export { router as userRoutes };
