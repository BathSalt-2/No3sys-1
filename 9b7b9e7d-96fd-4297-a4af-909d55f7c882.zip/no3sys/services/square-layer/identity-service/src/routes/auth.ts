import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { body, validationResult } from 'express-validator';
import { prisma, redis } from '../index';
import { generateTokens, verifyToken, authenticate } from '../middleware/auth';
import { AppError } from '../middleware/error-handler';
import { logger } from '../utils/logger';

const router = Router();
const SALT_ROUNDS = 12;

// Validation middleware
const validate = (req: any, res: any, next: any) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    throw new AppError(400, 'Validation failed', 'VALIDATION_ERROR', {
      errors: errors.array(),
    });
  }
  next();
};

// Register
router.post(
  '/register',
  [
    body('email').isEmail().normalizeEmail(),
    body('username').isAlphanumeric().isLength({ min: 3, max: 30 }),
    body('password').isLength({ min: 8 }),
    body('displayName').optional().trim().isLength({ max: 100 }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { email, username, password, displayName } = req.body;

      // Check if user exists
      const existingUser = await prisma.user.findFirst({
        where: {
          OR: [{ email }, { username }],
        },
      });

      if (existingUser) {
        throw new AppError(
          409,
          'User with this email or username already exists',
          'USER_EXISTS'
        );
      }

      // Hash password
      const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

      // Create user with default preferences
      const user = await prisma.user.create({
        data: {
          email,
          username,
          passwordHash,
          displayName,
          preferences: {
            create: {
              theme: 'system',
              language: 'en',
              timezone: 'UTC',
              notifications: {
                email: true,
                push: false,
                digest: 'daily',
              },
              privacy: {
                profileVisible: true,
                activityVisible: false,
              },
            },
          },
        },
        select: {
          id: true,
          email: true,
          username: true,
          displayName: true,
          createdAt: true,
        },
      });

      // Generate tokens
      const { accessToken, refreshToken } = generateTokens(user.id, user.email);

      // Store session
      await prisma.session.create({
        data: {
          userId: user.id,
          token: accessToken,
          refreshToken,
          ipAddress: req.ip,
          userAgent: req.headers['user-agent'],
          expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
        },
      });

      logger.info({
        message: 'User registered',
        userId: user.id,
        email: user.email,
      });

      res.status(201).json({
        user,
        tokens: {
          accessToken,
          refreshToken,
          expiresIn: 900, // 15 minutes
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

// Login
router.post(
  '/login',
  [
    body('email').isEmail().normalizeEmail(),
    body('password').exists(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { email, password } = req.body;

      // Find user
      const user = await prisma.user.findUnique({
        where: { email },
      });

      if (!user || !user.isActive) {
        throw new AppError(401, 'Invalid credentials', 'INVALID_CREDENTIALS');
      }

      // Verify password
      const isValid = await bcrypt.compare(password, user.passwordHash);
      if (!isValid) {
        throw new AppError(401, 'Invalid credentials', 'INVALID_CREDENTIALS');
      }

      // Update last login
      await prisma.user.update({
        where: { id: user.id },
        data: { lastLoginAt: new Date() },
      });

      // Generate tokens
      const { accessToken, refreshToken } = generateTokens(user.id, user.email);

      // Store session
      await prisma.session.create({
        data: {
          userId: user.id,
          token: accessToken,
          refreshToken,
          ipAddress: req.ip,
          userAgent: req.headers['user-agent'],
          expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        },
      });

      logger.info({
        message: 'User logged in',
        userId: user.id,
        email: user.email,
      });

      res.json({
        user: {
          id: user.id,
          email: user.email,
          username: user.username,
          displayName: user.displayName,
          avatarUrl: user.avatarUrl,
        },
        tokens: {
          accessToken,
          refreshToken,
          expiresIn: 900,
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

// Refresh token
router.post('/refresh', async (req, res, next) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      throw new AppError(400, 'Refresh token required', 'TOKEN_REQUIRED');
    }

    // Verify refresh token
    const payload = verifyToken(refreshToken);
    
    if (payload.type !== 'refresh') {
      throw new AppError(401, 'Invalid token type', 'INVALID_TOKEN_TYPE');
    }

    // Check if session exists
    const session = await prisma.session.findUnique({
      where: { refreshToken },
    });

    if (!session) {
      throw new AppError(401, 'Invalid refresh token', 'INVALID_REFRESH_TOKEN');
    }

    // Generate new tokens
    const tokens = generateTokens(payload.userId, payload.email);

    // Update session
    await prisma.session.update({
      where: { id: session.id },
      data: {
        token: tokens.accessToken,
        refreshToken: tokens.refreshToken,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });

    res.json({
      tokens: {
        accessToken: tokens.accessToken,
        refreshToken: tokens.refreshToken,
        expiresIn: 900,
      },
    });
  } catch (error) {
    if (error instanceof Error && error.name === 'JsonWebTokenError') {
      return next(new AppError(401, 'Invalid refresh token', 'INVALID_REFRESH_TOKEN'));
    }
    next(error);
  }
});

// Logout
router.post('/logout', authenticate, async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader!.substring(7);

    // Delete session
    await prisma.session.deleteMany({
      where: { token },
    });

    // Blacklist token
    await redis.setex(`blacklist:${token}`, 900, 'true');

    logger.info({
      message: 'User logged out',
      userId: req.user!.id,
    });

    res.json({ message: 'Logged out successfully' });
  } catch (error) {
    next(error);
  }
});

// Logout all sessions
router.post('/logout-all', authenticate, async (req, res, next) => {
  try {
    // Delete all user sessions
    const sessions = await prisma.session.findMany({
      where: { userId: req.user!.id },
    });

    // Blacklist all tokens
    for (const session of sessions) {
      await redis.setex(`blacklist:${session.token}`, 900, 'true');
    }

    await prisma.session.deleteMany({
      where: { userId: req.user!.id },
    });

    logger.info({
      message: 'User logged out from all sessions',
      userId: req.user!.id,
    });

    res.json({ message: 'Logged out from all sessions' });
  } catch (error) {
    next(error);
  }
});

// Get current user
router.get('/me', authenticate, async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user!.id },
      include: {
        preferences: true,
      },
    });

    if (!user) {
      throw new AppError(404, 'User not found', 'USER_NOT_FOUND');
    }

    res.json({
      id: user.id,
      email: user.email,
      username: user.username,
      displayName: user.displayName,
      avatarUrl: user.avatarUrl,
      isVerified: user.isVerified,
      lastLoginAt: user.lastLoginAt,
      createdAt: user.createdAt,
      preferences: user.preferences,
    });
  } catch (error) {
    next(error);
  }
});

// Change password
router.post(
  '/change-password',
  authenticate,
  [
    body('currentPassword').exists(),
    body('newPassword').isLength({ min: 8 }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { currentPassword, newPassword } = req.body;

      const user = await prisma.user.findUnique({
        where: { id: req.user!.id },
      });

      if (!user) {
        throw new AppError(404, 'User not found', 'USER_NOT_FOUND');
      }

      // Verify current password
      const isValid = await bcrypt.compare(currentPassword, user.passwordHash);
      if (!isValid) {
        throw new AppError(401, 'Current password is incorrect', 'INVALID_PASSWORD');
      }

      // Hash new password
      const newPasswordHash = await bcrypt.hash(newPassword, SALT_ROUNDS);

      // Update password
      await prisma.user.update({
        where: { id: user.id },
        data: { passwordHash: newPasswordHash },
      });

      // Logout all other sessions
      const sessions = await prisma.session.findMany({
        where: { userId: user.id },
      });

      for (const session of sessions) {
        await redis.setex(`blacklist:${session.token}`, 900, 'true');
      }

      await prisma.session.deleteMany({
        where: { userId: user.id },
      });

      logger.info({
        message: 'Password changed',
        userId: user.id,
      });

      res.json({ message: 'Password changed successfully. Please log in again.' });
    } catch (error) {
      next(error);
    }
  }
);

export { router as authRoutes };
