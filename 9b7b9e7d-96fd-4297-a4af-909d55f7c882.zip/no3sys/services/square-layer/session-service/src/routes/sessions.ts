import { Router } from 'express';
import { body } from 'express-validator';
import { v4 as uuidv4 } from 'uuid';
import { prisma, redis, kafkaProducer } from '../index';
import { AppError } from '../middleware/error-handler';
import { logger } from '../utils/logger';

const router = Router();

// Session State Machine
export enum SessionState {
  START = 'START',
  ENGAGE = 'ENGAGE',
  RESOLVE = 'RESOLVE',
  ARCHIVE = 'ARCHIVE',
}

export enum SessionEvent {
  INITIATE = 'INITIATE',
  ACTIVATE = 'ACTIVATE',
  CONCLUDE = 'CONCLUDE',
  FINALIZE = 'FINALIZE',
  REACTIVATE = 'REACTIVATE',
}

// State transitions
const stateTransitions: Record<SessionState, Partial<Record<SessionEvent, SessionState>>> = {
  [SessionState.START]: {
    [SessionEvent.INITIATE]: SessionState.START,
    [SessionEvent.ACTIVATE]: SessionState.ENGAGE,
  },
  [SessionState.ENGAGE]: {
    [SessionEvent.CONCLUDE]: SessionState.RESOLVE,
    [SessionEvent.ACTIVATE]: SessionState.ENGAGE,
  },
  [SessionState.RESOLVE]: {
    [SessionEvent.FINALIZE]: SessionState.ARCHIVE,
    [SessionEvent.REACTIVATE]: SessionState.ENGAGE,
  },
  [SessionState.ARCHIVE]: {
    [SessionEvent.REACTIVATE]: SessionState.ENGAGE,
  },
};

// Emit session event to Kafka
const emitSessionEvent = async (
  sessionId: string,
  event: SessionEvent,
  fromState: SessionState,
  toState: SessionState,
  metadata?: Record<string, any>
) => {
  try {
    await kafkaProducer.send({
      topic: 'session-events',
      messages: [
        {
          key: sessionId,
          value: JSON.stringify({
            sessionId,
            event,
            fromState,
            toState,
            timestamp: new Date().toISOString(),
            metadata,
          }),
        },
      ],
    });
  } catch (error) {
    logger.error('Failed to emit session event:', error);
  }
};

// Create session
router.post('/', async (req, res, next) => {
  try {
    const { userId, title, context, metadata } = req.body;

    const session = await prisma.session.create({
      data: {
        id: uuidv4(),
        userId,
        title: title || 'New Session',
        state: SessionState.START,
        context: context || {},
        metadata: metadata || {},
      },
    });

    // Cache session state
    await redis.setex(
      `session:${session.id}`,
      3600,
      JSON.stringify({ state: SessionState.START, userId })
    );

    // Emit event
    await emitSessionEvent(session.id, SessionEvent.INITIATE, SessionState.START, SessionState.START);

    logger.info({ message: 'Session created', sessionId: session.id, userId });

    res.status(201).json(session);
  } catch (error) {
    next(error);
  }
});

// Get session by ID
router.get('/:sessionId', async (req, res, next) => {
  try {
    const { sessionId } = req.params;

    // Try cache first
    const cached = await redis.get(`session:${sessionId}`);
    if (cached) {
      const parsed = JSON.parse(cached);
      return res.json({ id: sessionId, ...parsed });
    }

    const session = await prisma.session.findUnique({
      where: { id: sessionId },
    });

    if (!session) {
      throw new AppError(404, 'Session not found', 'SESSION_NOT_FOUND');
    }

    // Update cache
    await redis.setex(
      `session:${sessionId}`,
      3600,
      JSON.stringify({ state: session.state, userId: session.userId })
    );

    res.json(session);
  } catch (error) {
    next(error);
  }
});

// Transition session state
router.post('/:sessionId/transition', async (req, res, next) => {
  try {
    const { sessionId } = req.params;
    const { event, metadata } = req.body;

    const sessionEvent = event as SessionEvent;

    // Get current session
    const session = await prisma.session.findUnique({
      where: { id: sessionId },
    });

    if (!session) {
      throw new AppError(404, 'Session not found', 'SESSION_NOT_FOUND');
    }

    const currentState = session.state as SessionState;
    const transitions = stateTransitions[currentState];
    const nextState = transitions?.[sessionEvent];

    if (!nextState) {
      throw new AppError(
        400,
        `Invalid transition: ${event} from ${currentState}`,
        'INVALID_TRANSITION'
      );
    }

    // Update session
    const updated = await prisma.session.update({
      where: { id: sessionId },
      data: {
        state: nextState,
        metadata: {
          ...((session.metadata as object) || {}),
          ...((metadata as object) || {}),
          lastTransition: {
            event: sessionEvent,
            from: currentState,
            to: nextState,
            at: new Date().toISOString(),
          },
        },
      },
    });

    // Update cache
    await redis.setex(
      `session:${sessionId}`,
      3600,
      JSON.stringify({ state: nextState, userId: session.userId })
    );

    // Emit event
    await emitSessionEvent(sessionId, sessionEvent, currentState, nextState, metadata);

    logger.info({
      message: 'Session state transitioned',
      sessionId,
      from: currentState,
      to: nextState,
      event: sessionEvent,
    });

    res.json(updated);
  } catch (error) {
    next(error);
  }
});

// List user sessions
router.get('/user/:userId', async (req, res, next) => {
  try {
    const { userId } = req.params;
    const { state, limit = '20', offset = '0' } = req.query;

    const where: any = { userId };
    if (state) where.state = state;

    const sessions = await prisma.session.findMany({
      where,
      orderBy: { updatedAt: 'desc' },
      take: parseInt(limit as string),
      skip: parseInt(offset as string),
    });

    const total = await prisma.session.count({ where });

    res.json({ sessions, total, limit: parseInt(limit as string), offset: parseInt(offset as string) });
  } catch (error) {
    next(error);
  }
});

// Get session state machine definition
router.get('/fsm/definition', (req, res) => {
  res.json({
    states: Object.values(SessionState),
    events: Object.values(SessionEvent),
    transitions: stateTransitions,
  });
});

export { router as sessionRoutes };
