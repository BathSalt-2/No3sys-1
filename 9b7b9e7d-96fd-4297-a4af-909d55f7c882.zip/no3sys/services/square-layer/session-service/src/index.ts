import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { PrismaClient } from '@prisma/client';
import Redis from 'ioredis';
import { Kafka } from 'kafkajs';
import { logger } from './utils/logger';
import { sessionRoutes } from './routes/sessions';
import { errorHandler } from './middleware/error-handler';
import { requestId } from './middleware/request-id';

const app = express();
const port = process.env.PORT || 3002;

// Initialize clients
export const prisma = new PrismaClient();
export const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

// Initialize Kafka
const kafka = new Kafka({
  clientId: 'session-service',
  brokers: (process.env.KAFKA_BROKERS || 'localhost:9092').split(','),
});

export const kafkaProducer = kafka.producer();

// Connect to Kafka
const connectKafka = async () => {
  try {
    await kafkaProducer.connect();
    logger.info('Connected to Kafka');
  } catch (error) {
    logger.error('Failed to connect to Kafka:', error);
  }
};

connectKafka();

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan('combined', { stream: { write: (msg) => logger.info(msg.trim()) } }));
app.use(requestId);

// Health check
app.get('/health', async (req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    await redis.ping();
    res.json({
      status: 'healthy',
      service: 'session-service',
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    res.status(503).json({ status: 'unhealthy', error: 'Service dependency failed' });
  }
});

// Routes
app.use('/sessions', sessionRoutes);

// Error handling
app.use(errorHandler);

// Graceful shutdown
const gracefulShutdown = async () => {
  await kafkaProducer.disconnect();
  await prisma.$disconnect();
  await redis.quit();
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

app.listen(port, () => {
  logger.info(`Session Service running on port ${port}`);
});
