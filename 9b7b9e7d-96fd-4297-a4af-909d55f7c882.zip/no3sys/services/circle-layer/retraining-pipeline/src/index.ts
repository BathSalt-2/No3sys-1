import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { PrismaClient } from '@prisma/client';
import Redis from 'ioredis';
import { Kafka } from 'kafkajs';
import { logger } from './utils/logger';
import { pipelineRoutes } from './routes/pipeline';
import { metricsRoutes } from './routes/metrics';
import { errorHandler } from './middleware/error-handler';
import { requestId } from './middleware/request-id';

const app = express();
const port = process.env.PORT || 3011;

export const prisma = new PrismaClient();
export const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

// Initialize Kafka
const kafka = new Kafka({
  clientId: 'retraining-pipeline',
  brokers: (process.env.KAFKA_BROKERS || 'localhost:9092').split(','),
});

export const kafkaConsumer = kafka.consumer({ groupId: 'retraining' });
export const kafkaProducer = kafka.producer();

// Start pipeline processor
const startPipelineProcessor = async () => {
  await kafkaProducer.connect();
  await kafkaConsumer.connect();
  
  await kafkaConsumer.subscribe({ topic: 'feedback-submitted', fromBeginning: false });
  
  await kafkaConsumer.run({
    eachMessage: async ({ topic, partition, message }) => {
      try {
        const data = JSON.parse(message.value?.toString() || '{}');
        logger.info({ message: 'Processing feedback for retraining', data });
        
        // Aggregate feedback for model evaluation
        await aggregateFeedback(data);
      } catch (error) {
        logger.error('Error processing feedback:', error);
      }
    },
  });
};

const aggregateFeedback = async (feedbackData: any) => {
  // Implementation for feedback aggregation
  logger.info({ message: 'Aggregating feedback', feedbackId: feedbackData.feedbackId });
};

startPipelineProcessor();

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan('combined', { stream: { write: (msg) => logger.info(msg.trim()) } }));
app.use(requestId);

app.get('/health', async (req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    await redis.ping();
    res.json({ status: 'healthy', service: 'retraining-pipeline' });
  } catch (error) {
    res.status(503).json({ status: 'unhealthy' });
  }
});

app.use('/pipeline', pipelineRoutes);
app.use('/metrics', metricsRoutes);

app.use(errorHandler);

const gracefulShutdown = async () => {
  await kafkaConsumer.disconnect();
  await kafkaProducer.disconnect();
  await prisma.$disconnect();
  await redis.quit();
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

app.listen(port, () => {
  logger.info(`Retraining Pipeline running on port ${port}`);
});
