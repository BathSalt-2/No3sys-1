import { Router } from 'express';
import { prisma } from '../index';
import { logger } from '../utils/logger';

const router = Router();

// Get model performance metrics
router.get('/performance', async (req, res, next) => {
  try {
    const { modelType, startDate, endDate } = req.query;

    const where: any = {};
    if (modelType) where.modelType = modelType;
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = new Date(startDate as string);
      if (endDate) where.createdAt.lte = new Date(endDate as string);
    }

    const runs = await prisma.trainingRun.findMany({
      where: { ...where, status: 'completed' },
      select: {
        id: true,
        modelType: true,
        modelVersion: true,
        metrics: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    // Aggregate metrics
    const aggregated = runs.reduce((acc: any, run: any) => {
      const type = run.modelType;
      if (!acc[type]) acc[type] = { runs: [], avgMetrics: {} };
      acc[type].runs.push(run);
      return acc;
    }, {});

    res.json({ metrics: runs, aggregated });
  } catch (error) {
    next(error);
  }
});

// Get feedback-based metrics
router.get('/feedback', async (req, res, next) => {
  try {
    const { startDate, endDate } = req.query;

    const where: any = {};
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = new Date(startDate as string);
      if (endDate) where.createdAt.lte = new Date(endDate as string);
    }

    const stats = await prisma.$queryRaw`
      SELECT 
        DATE_TRUNC('day', created_at) as date,
        AVG(rating) as avg_rating,
        COUNT(*) as total_feedback,
        SUM(CASE WHEN rating >= 4 THEN 1 ELSE 0 END) as positive_count,
        SUM(CASE WHEN rating <= 2 THEN 1 ELSE 0 END) as negative_count
      FROM feedback
      WHERE ${where.createdAt ? `created_at >= '${where.createdAt.gte}' AND created_at <= '${where.createdAt.lte}'` : '1=1'}
      GROUP BY DATE_TRUNC('day', created_at)
      ORDER BY date DESC
    `;

    res.json({ feedbackStats: stats });
  } catch (error) {
    next(error);
  }
});

export { router as metricsRoutes };
