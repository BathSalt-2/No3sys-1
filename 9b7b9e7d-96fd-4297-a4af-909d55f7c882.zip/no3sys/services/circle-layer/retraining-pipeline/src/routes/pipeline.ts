import { Router } from 'express';
import { prisma, kafkaProducer } from '../index';
import { AppError } from '../middleware/error-handler';
import { logger } from '../utils/logger';

const router = Router();

// Trigger training run
router.post('/train', async (req, res, next) => {
  try {
    const { modelType, datasetConfig, hyperparameters } = req.body;

    const trainingRun = await prisma.trainingRun.create({
      data: {
        modelType,
        datasetConfig: datasetConfig || {},
        hyperparameters: hyperparameters || {},
        status: 'pending',
      },
    });

    // Emit training event
    await kafkaProducer.send({
      topic: 'training-triggered',
      messages: [
        {
          key: trainingRun.id,
          value: JSON.stringify({
            runId: trainingRun.id,
            modelType,
            datasetConfig,
            hyperparameters,
            timestamp: new Date().toISOString(),
          }),
        },
      ],
    });

    logger.info({ message: 'Training triggered', runId: trainingRun.id, modelType });

    res.status(202).json({
      message: 'Training run initiated',
      runId: trainingRun.id,
      status: 'pending',
    });
  } catch (error) {
    next(error);
  }
});

// Get training run status
router.get('/:runId', async (req, res, next) => {
  try {
    const { runId } = req.params;

    const run = await prisma.trainingRun.findUnique({
      where: { id: runId },
    });

    if (!run) {
      throw new AppError(404, 'Training run not found', 'RUN_NOT_FOUND');
    }

    res.json(run);
  } catch (error) {
    next(error);
  }
});

// List training runs
router.get('/', async (req, res, next) => {
  try {
    const { status, limit = '20', offset = '0' } = req.query;

    const where: any = {};
    if (status) where.status = status;

    const runs = await prisma.trainingRun.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: parseInt(limit as string),
      skip: parseInt(offset as string),
    });

    const total = await prisma.trainingRun.count({ where });

    res.json({ runs, total });
  } catch (error) {
    next(error);
  }
});

// Update training run status (webhook from training infrastructure)
router.patch('/:runId/status', async (req, res, next) => {
  try {
    const { runId } = req.params;
    const { status, metrics, modelVersion } = req.body;

    const updated = await prisma.trainingRun.update({
      where: { id: runId },
      data: {
        status,
        metrics: metrics || undefined,
        modelVersion: modelVersion || undefined,
        completedAt: status === 'completed' ? new Date() : undefined,
      },
    });

    // If completed successfully, emit deployment event
    if (status === 'completed' && modelVersion) {
      await kafkaProducer.send({
        topic: 'model-ready-for-deployment',
        messages: [
          {
            key: runId,
            value: JSON.stringify({
              runId,
              modelVersion,
              modelType: updated.modelType,
              metrics,
              timestamp: new Date().toISOString(),
            }),
          },
        ],
      });
    }

    res.json(updated);
  } catch (error) {
    next(error);
  }
});

export { router as pipelineRoutes };
