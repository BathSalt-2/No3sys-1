import { Router } from 'express';
import { prisma, redis, openai } from '../index';
import { AppError } from '../middleware/error-handler';
import { logger } from '../utils/logger';

const router = Router();

// Generate summary using OpenAI
const generateSummary = async (content: string): Promise<string> => {
  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: 'Summarize the following content concisely while preserving key information:',
        },
        { role: 'user', content },
      ],
      max_tokens: 200,
    });
    return response.choices[0]?.message?.content || '';
  } catch (error) {
    logger.error('Failed to generate summary:', error);
    return '';
  }
};

// Generate embedding
const generateEmbedding = async (content: string): Promise<number[]> => {
  try {
    const response = await openai.embeddings.create({
      model: 'text-embedding-3-small',
      input: content,
    });
    return response.data[0].embedding;
  } catch (error) {
    logger.error('Failed to generate embedding:', error);
    return [];
  }
};

// Create memory summary
router.post('/summarize', async (req, res, next) => {
  try {
    const { conversationId, content } = req.body;

    const summary = await generateSummary(content);
    const embedding = await generateEmbedding(summary);

    const memory = await prisma.memory.create({
      data: {
        conversationId,
        type: 'summary',
        content: summary,
        embedding: embedding.length > 0 ? embedding : undefined,
        metadata: { source: 'ai-generated' },
      },
    });

    // Cache for fast recall
    await redis.setex(`memory:${memory.id}`, 86400, JSON.stringify(memory));

    res.status(201).json(memory);
  } catch (error) {
    next(error);
  }
});

// Semantic search across memories
router.post('/search', async (req, res, next) => {
  try {
    const { query, userId, limit = '10' } = req.body;

    const queryEmbedding = await generateEmbedding(query);

    if (queryEmbedding.length === 0) {
      throw new AppError(500, 'Failed to generate embedding', 'EMBEDDING_ERROR');
    }

    // Search using pgvector
    const memories = await prisma.$queryRaw`
      SELECT id, type, content, metadata, created_at,
             embedding <=> ${queryEmbedding}::vector as distance
      FROM memories
      WHERE user_id = ${userId}
      ORDER BY embedding <=> ${queryEmbedding}::vector
      LIMIT ${parseInt(limit)}
    `;

    res.json({ memories, query });
  } catch (error) {
    next(error);
  }
});

// Get memories for conversation
router.get('/conversation/:conversationId', async (req, res, next) => {
  try {
    const { conversationId } = req.params;

    const memories = await prisma.memory.findMany({
      where: { conversationId },
      orderBy: { createdAt: 'desc' },
    });

    res.json({ memories });
  } catch (error) {
    next(error);
  }
});

// Recall recent memories (sub-100ms with Redis)
router.get('/recall/:userId', async (req, res, next) => {
  const startTime = Date.now();
  try {
    const { userId } = req.params;
    const { limit = '10' } = req.query;

    // Try Redis first
    const cached = await redis.get(`memories:user:${userId}`);
    if (cached) {
      const memories = JSON.parse(cached);
      return res.json({
        memories: memories.slice(0, parseInt(limit as string)),
        source: 'cache',
        latencyMs: Date.now() - startTime,
      });
    }

    // Fallback to database
    const memories = await prisma.memory.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: parseInt(limit as string),
    });

    // Cache results
    await redis.setex(`memories:user:${userId}`, 300, JSON.stringify(memories));

    res.json({
      memories,
      source: 'database',
      latencyMs: Date.now() - startTime,
    });
  } catch (error) {
    next(error);
  }
});

export { router as memoryRoutes };
