import { Router } from 'express';
import { prisma, kafkaProducer } from '../index';
import { AppError } from '../middleware/error-handler';
import { logger } from '../utils/logger';

const router = Router();

// Submit feedback
router.post('/', async (req, res, next) => {
  try {
    const { messageId, rating, comment, tags = [] } = req.body;

    const feedback = await prisma.feedback.create({
      data: {
        messageId,
        rating,
        comment,
        tags,
      },
    });

    // Emit feedback event for downstream processing
    await kafkaProducer.send({
      topic: 'feedback-submitted',
      messages: [
        {
          key: messageId,
          value: JSON.stringify({
            feedbackId: feedback.id,
            messageId,
            rating,
            tags,
            timestamp: new Date().toISOString(),
          }),
        },
      ],
    });

    logger.info({ message: 'Feedback submitted', feedbackId: feedback.id, rating });

    res.status(201).json(feedback);
  } catch (error) {
    next(error);
  }
});

// Get feedback statistics
router.get('/stats', async (req, res, next) => {
  try {
    const { messageId, conversationId, startDate, endDate } = req.query;

    const where: any = {};
    if (messageId) where.messageId = messageId;
    if (conversationId) where.conversationId = conversationId;
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = new Date(startDate as string);
      if (endDate) where.createdAt.lte = new Date(endDate as string);
    }

    const stats = await prisma.feedback.groupBy({
      by: ['rating'],
      where,
      _count: { rating: true },
      _avg: { rating: true },
    });

    const total = await prisma.feedback.count({ where });

    res.json({ stats, total });
  } catch (error) {
    next(error);
  }
});

// Get feedback by message
router.get('/message/:messageId', async (req, res, next) => {
  try {
    const { messageId } = req.params;

    const feedback = await prisma.feedback.findMany({
      where: { messageId },
      orderBy: { createdAt: 'desc' },
    });

    res.json({ feedback });
  } catch (error) {
    next(error);
  }
});

export { router as feedbackRoutes };
