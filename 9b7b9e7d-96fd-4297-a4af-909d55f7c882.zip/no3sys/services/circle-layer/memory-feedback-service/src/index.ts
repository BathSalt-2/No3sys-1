import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { PrismaClient } from '@prisma/client';
import Redis from 'ioredis';
import { Kafka } from 'kafkajs';
import OpenAI from 'openai';
import { logger } from './utils/logger';
import { memoryRoutes } from './routes/memory';
import { feedbackRoutes } from './routes/feedback';
import { errorHandler } from './middleware/error-handler';
import { requestId } from './middleware/request-id';

const app = express();
const port = process.env.PORT || 3010;

export const prisma = new PrismaClient();
export const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');
export const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Initialize Kafka
const kafka = new Kafka({
  clientId: 'memory-feedback-service',
  brokers: (process.env.KAFKA_BROKERS || 'localhost:9092').split(','),
});

export const kafkaConsumer = kafka.consumer({ groupId: 'memory-feedback' });
export const kafkaProducer = kafka.producer();

// Start Kafka consumer for message events
const startKafkaConsumer = async () => {
  await kafkaProducer.connect();
  await kafkaConsumer.connect();
  
  await kafkaConsumer.subscribe({ topic: 'message-created', fromBeginning: false });
  
  await kafkaConsumer.run({
    eachMessage: async ({ topic, partition, message }) => {
      try {
        const data = JSON.parse(message.value?.toString() || '{}');
        logger.info({ message: 'Processing message for memory', data });
        
        // Process message for memory storage and summarization
        await processMessageForMemory(data);
      } catch (error) {
        logger.error('Error processing message:', error);
      }
    },
  });
};

// Process message for memory
const processMessageForMemory = async (messageData: any) => {
  // Implementation for summarization and memory storage
  logger.info({ message: 'Processing for memory', messageId: messageData.id });
};

startKafkaConsumer();

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan('combined', { stream: { write: (msg) => logger.info(msg.trim()) } }));
app.use(requestId);

app.get('/health', async (req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    await redis.ping();
    res.json({ status: 'healthy', service: 'memory-feedback-service' });
  } catch (error) {
    res.status(503).json({ status: 'unhealthy' });
  }
});

app.use('/memory', memoryRoutes);
app.use('/feedback', feedbackRoutes);

app.use(errorHandler);

const gracefulShutdown = async () => {
  await kafkaConsumer.disconnect();
  await kafkaProducer.disconnect();
  await prisma.$disconnect();
  await redis.quit();
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

app.listen(port, () => {
  logger.info(`Memory Feedback Service running on port ${port}`);
});
